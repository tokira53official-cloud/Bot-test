# PteroManager

1. `pkg install python clang make libffi openssl` (Termux)  •  `pip install -r requirements.txt`
2. `cp .env.example .env` and fill it in
3. `python shard.py`

Discord Developer Portal → Bot → enable **Server Members** and **Message Content** intents.
Give the bot **Manage Roles** and put its role ABOVE the Free/Premium/VIP roles.
Files: `assets/banner.png` (4K, sent with every embed) • `data_recovery.jsonl` (auto-created safety journal).

## v2 additions
- `!manage` (buttons: start / stop / restart / delete) needs `PTERO_CLIENT_API_KEY` — the *client* API key (Account → API Credentials) of a **root admin** account.
- `!listservers [py|js|mc]` (admin) lists every panel server on that egg, with buttons + paging.
- Suspending a server (via `!suspend` **or** in the panel) DMs the owner. The panel is polled every 2 minutes.
- `!resetpassword`, `!broadcast <channel|dm> <msg>` (owner).

## v3 additions (63 commands)
Server control (`!start !stop !restart !kill !sendcmd !serverstatus !rename !reinstall !address !backup !backups !deletebackup !files !startup !setvar !databases !schedules !server`),
account (`!tiers !quota !mystats !whoami !leaderboard !changeemail !changeusername !feedback`),
info (`!avatar !servericon !membercount !roleinfo !channelinfo !botinfo !shardinfo !prefix !roles`),
admin (`!panelstats !nodes !locations !nests !eggs !findserver !panelusers !setlimits !setplan !transfer !reinstallserver !lookup !suspendall !unsuspendall`),
moderation (`!warn !warns !clearwarns !purge`),
owner (`!auditlog !maintenance !forcedelete !purgeuser !guilds !say !dm !shutdown !restartbot !exportdata`).
All server-control commands except the power/console ones need `PTERO_CLIENT_API_KEY` (client API key of a root admin).
