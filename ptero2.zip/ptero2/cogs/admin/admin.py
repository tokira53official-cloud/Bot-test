import discord
from discord.ext import commands

from core.checks import admin_only
from core.embeds import e_done, e_err, e_info, e_prog, edit_embed, send_embed
from core.ptero import PteroError
from core.service import KIND_ALIASES, ProvisionError, give_role, notify_suspension, provision, server_url, take_role
from core.views import ConfirmView


class Admin(commands.Cog):
    category = "admin"

    def __init__(self, bot):
        self.bot = bot

    @commands.command(brief="Create a server for a member", usage="<@member> <js|py|mc> [free|premium|vip] [name]")
    @admin_only()
    async def create(self, ctx, member: discord.Member, kind: str, tier: str = "vip", *, name: str = None):
        kind_key = KIND_ALIASES.get(kind.lower())
        tier = tier.lower()
        if not kind_key or tier not in self.bot.cfg.tiers:
            return await send_embed(ctx, e_err("Invalid", "Type: `js|py|mc` • Tier: `free|premium|vip`"), delete_after=10)
        msg = await send_embed(ctx, e_prog("Creating server…", f"For {member.mention}"))
        try:
            r = await provision(self.bot, member.id, tier, kind_key, name=name, bypass=True)
        except ProvisionError as e:
            return await edit_embed(msg, e_err("Could not create server", str(e)))
        await self.bot.db.audit(ctx.author.id, "create", f"{member.id}:{r['id']}")
        t = r["tier"]
        emb = e_done("Server created", f"**{r['name']}** for {member.mention}\n[Open in panel]({r['url']})")
        emb.add_field(name="Specs", value=f"RAM `{t.ram} MB`\nDisk `{t.disk} MB`\nCPU `{t.cpu}%`")
        emb.add_field(name="Info", value=f"ID `{r['id']}`\nTier `{t.label}`")
        await edit_embed(msg, emb)

    @commands.command(brief="Delete any tracked server", usage="<server_id>")
    @admin_only()
    async def delete(self, ctx, server_id: int):
        row = await self.bot.db.get_server(server_id)
        if not row:
            return await send_embed(ctx, e_err("Not found", "No active server with that ID."), delete_after=10)
        view = ConfirmView(ctx.author.id)
        msg = await send_embed(ctx, e_prog("Delete server?", f"**{row['name']}** (owner <@{row['discord_id']}>)"), view=view)
        await view.wait()
        if not view.value:
            return await edit_embed(msg, e_info("Cancelled"), view=None)
        try:
            await self.bot.ptero.delete_server(server_id)
        except PteroError as e:
            if e.status != 404:
                return await edit_embed(msg, e_err("Panel error", e.message[:300]), view=None)
        await self.bot.db.mark_deleted(server_id)
        await self.bot.db.audit(ctx.author.id, "delete", str(server_id))
        await edit_embed(msg, e_done("Server deleted", row["name"]), view=None)

    async def _suspend(self, ctx, server_id: int, suspend: bool):
        try:
            attrs = await self.bot.ptero.get_server(server_id)
            await (self.bot.ptero.suspend(server_id) if suspend else self.bot.ptero.unsuspend(server_id))
        except PteroError as e:
            return await send_embed(ctx, e_err("Panel error", e.message[:300]), delete_after=10)
        await self.bot.db.set_suspended(server_id, suspend)
        await self.bot.db.audit(ctx.author.id, "suspend" if suspend else "unsuspend", str(server_id))
        sent = await notify_suspension(self.bot, attrs, suspend)
        note = {True: "The owner was notified by DM.", False: "Couldn't DM the owner (DMs closed).",
                None: "Owner isn't linked to a Discord account — no DM sent."}[sent]
        await send_embed(ctx, e_done("Suspended" if suspend else "Unsuspended",
                                     f"Server `{server_id}` (**{attrs.get('name', '?')}**)\n{note}"))

    @commands.command(brief="Suspend a server (owner gets a DM)", usage="<server_id>")
    @admin_only()
    async def suspend(self, ctx, server_id: int):
        await self._suspend(ctx, server_id, True)

    @commands.command(brief="Unsuspend a server (owner gets a DM)", usage="<server_id>")
    @admin_only()
    async def unsuspend(self, ctx, server_id: int):
        await self._suspend(ctx, server_id, False)

    @commands.command(name="user-servers", brief="List a member's servers", usage="<@member>")
    @admin_only()
    async def user_servers(self, ctx, member: discord.Member):
        rows = await self.bot.db.user_servers(member.id)
        if not rows:
            return await send_embed(ctx, e_info("No servers", f"{member.mention} has none."), delete_after=15)
        lines = [f"**{r['name']}** • ID `{r['ptero_server_id']}` • {r['kind'].upper()} • {r['tier'].title()} • "
                 f"[open]({server_url(self.bot.cfg, r['identifier'])})" for r in rows]
        await send_embed(ctx, e_info(f"{member.display_name}'s servers", "\n".join(lines)[:4000]))

    @commands.command(name="add-user", brief="Give a member the premium or vip role", usage="<@member|id> <premium|vip>")
    @admin_only()
    async def add_user(self, ctx, member: discord.Member, tier: str):
        tier = tier.lower()
        if tier not in ("premium", "vip"):
            return await send_embed(ctx, e_err("Invalid tier", "Use `premium` or `vip` (free is automatic)."), delete_after=10)
        t = self.bot.cfg.tiers[tier]
        if not await give_role(self.bot, member.id, t.role_id, f"add-user by {ctx.author}"):
            return await send_embed(ctx, e_err("Failed", f"Check `{tier.upper()}_ROLE_ID` and my role position."), delete_after=10)
        await self.bot.db.audit(ctx.author.id, "add-user", f"{member.id}:{tier}")
        await send_embed(ctx, e_done("Role added", f"{member.mention} is now **{t.label}**."))

    @commands.command(name="remove-user", brief="Remove premium or vip role", usage="<@member|id> <premium|vip>")
    @admin_only()
    async def remove_user(self, ctx, member: discord.Member, tier: str):
        tier = tier.lower()
        if tier not in ("premium", "vip"):
            return await send_embed(ctx, e_err("Invalid tier", "Use `premium` or `vip`."), delete_after=10)
        await take_role(self.bot, member.id, self.bot.cfg.tiers[tier].role_id, f"remove-user by {ctx.author}")
        await self.bot.db.audit(ctx.author.id, "remove-user", f"{member.id}:{tier}")
        await send_embed(ctx, e_done("Role removed", f"{member.mention} is no longer **{tier.title()}**."))


async def setup(bot):
    await bot.add_cog(Admin(bot))
