import math

import discord
from discord import ui
from discord.ext import commands

from core.checks import admin_only
from core.embeds import e_err, e_main, ge, send_embed
from core.ptero import PteroError
from core.service import KIND_ALIASES


class ListView(ui.View):
    PER = 8

    def __init__(self, bot, uid, servers, owners, kind):
        super().__init__(timeout=180)
        self.bot, self.uid, self.servers, self.owners = bot, uid, servers, owners
        self.kind, self.page, self.message = kind, 0, None
        self._refresh()

    def _items(self):
        egg = self.bot.cfg.kinds[self.kind].egg_id
        return [s for s in self.servers if egg and s.get("egg") == egg]

    def _pages(self):
        return max(1, math.ceil(len(self._items()) / self.PER))

    def _refresh(self):
        self.clear_items()
        for key in ("py", "js", "mc"):
            b = ui.Button(label=self.bot.cfg.kinds[key].label, row=0,
                          style=discord.ButtonStyle.primary if key == self.kind else discord.ButtonStyle.secondary)
            b.callback = self._kind_cb(key)
            self.add_item(b)
        prev = ui.Button(label="◀ Prev", style=discord.ButtonStyle.secondary, row=1, disabled=self.page <= 0)
        prev.callback = self.prev
        ind = ui.Button(label=f"{self.page + 1}/{self._pages()}", style=discord.ButtonStyle.secondary, row=1, disabled=True)
        nxt = ui.Button(label="Next ▶", style=discord.ButtonStyle.secondary, row=1, disabled=self.page + 1 >= self._pages())
        nxt.callback = self.next
        for b in (prev, ind, nxt):
            self.add_item(b)

    def build(self) -> discord.Embed:
        items = self._items()
        label = self.bot.cfg.kinds[self.kind].label
        chunk = items[self.page * self.PER:(self.page + 1) * self.PER]
        lines = []
        for s in chunk:
            uid = self.owners.get(s.get("user"))
            owner = f"<@{uid}>" if uid else f"panel user `{s.get('user')}`"
            lines.append(f"{'⛔' if s.get('suspended') else '🟢'} **{s['name'][:30]}** • `{s['id']}` • {owner}")
        egg = self.bot.cfg.kinds[self.kind].egg_id
        empty = "Egg not configured in `.env`." if not egg else "No servers on this egg."
        return e_main(f"{ge('list', '📋')} {label} servers ({len(items)})", "\n".join(lines) or empty)

    def _kind_cb(self, key):
        async def cb(inter: discord.Interaction):
            if inter.user.id != self.uid:
                return
            self.kind, self.page = key, 0
            self._refresh()
            await inter.response.edit_message(embed=self.build(), view=self)
        return cb

    async def prev(self, inter):
        if inter.user.id != self.uid:
            return
        self.page = max(0, self.page - 1)
        self._refresh()
        await inter.response.edit_message(embed=self.build(), view=self)

    async def next(self, inter):
        if inter.user.id != self.uid:
            return
        self.page = min(self._pages() - 1, self.page + 1)
        self._refresh()
        await inter.response.edit_message(embed=self.build(), view=self)

    async def on_timeout(self):
        if self.message:
            try:
                await self.message.edit(view=None)
            except discord.HTTPException:
                pass


class ListServers(commands.Cog):
    category = "admin"

    def __init__(self, bot):
        self.bot = bot

    @commands.command(brief="List every panel server per egg (py/js/mc buttons)", usage="[py|js|mc]")
    @admin_only()
    async def listservers(self, ctx, kind: str = "py"):
        kind = KIND_ALIASES.get(kind.lower(), "py")
        try:
            servers = await self.bot.ptero.list_servers()
        except PteroError as e:
            return await send_embed(ctx, e_err("Panel error", e.message[:300]), delete_after=10)
        owners = await self.bot.db.accounts_by_ptero_users([s.get("user") for s in servers if s.get("user")])
        view = ListView(self.bot, ctx.author.id, servers, owners, kind)
        view.message = await send_embed(ctx, view.build(), view=view)


async def setup(bot):
    await bot.add_cog(ListServers(bot))
