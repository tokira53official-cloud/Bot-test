import discord
from discord.ext import commands

from core.checks import admin_only
from core.embeds import e_done, e_err, e_info, send_embed
from core.service import dm


class Moderation(commands.Cog):
    category = "moderation"

    def __init__(self, bot):
        self.bot = bot

    def _protected(self, member) -> bool:
        return member.bot or member.id in self.bot.cfg.owner_ids or member.id in self.bot.admin_ids

    @commands.command(brief="Warn a member (they get a DM)", usage="<@member> [reason]")
    @admin_only()
    @commands.guild_only()
    async def warn(self, ctx, member: discord.Member, *, reason: str = "No reason given"):
        if self._protected(member):
            return await send_embed(ctx, e_err("Denied", "You can't warn bots, admins or owners."), delete_after=8)
        await self.bot.db.add_warning(member.id, ctx.author.id, reason[:500])
        n = len(await self.bot.db.get_warnings(member.id))
        await dm(self.bot, member.id, e_err("You were warned", f"**Reason:** {reason[:500]}\nTotal warnings: `{n}`"))
        await send_embed(ctx, e_done("Member warned", f"{member.mention} now has `{n}` warning(s).\n**Reason:** {reason[:300]}"))

    @commands.command(brief="Show a member's warnings", usage="[@member]")
    @admin_only()
    @commands.guild_only()
    async def warns(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        rows = await self.bot.db.get_warnings(member.id)
        lines = [f"`{i}.` <t:{int(r['at'].timestamp())}:R> by <@{r['mod_id']}> — {r['reason'][:80]}" for i, r in enumerate(rows[-10:], 1)]
        await send_embed(ctx, e_info(f"Warnings — {member.display_name} ({len(rows)})", "\n".join(lines) or "No warnings."))

    @commands.command(brief="Clear all warnings of a member", usage="<@member>")
    @admin_only()
    @commands.guild_only()
    async def clearwarns(self, ctx, member: discord.Member):
        n = await self.bot.db.clear_warnings(member.id)
        await self.bot.db.audit(ctx.author.id, "clearwarns", f"{member.id}:{n}")
        await send_embed(ctx, e_done("Warnings cleared", f"Removed `{n}` warning(s) from {member.mention}."))

    @commands.command(brief="Bulk-delete messages (1-100)", usage="<amount>")
    @admin_only()
    @commands.guild_only()
    async def purge(self, ctx, amount: int):
        if not 1 <= amount <= 100:
            return await send_embed(ctx, e_err("Invalid amount", "Choose a number from 1 to 100."), delete_after=8)
        try:
            deleted = await ctx.channel.purge(limit=amount + 1)
        except discord.Forbidden:
            return await send_embed(ctx, e_err("Missing permission", "I need **Manage Messages** here."), delete_after=8)
        await send_embed(ctx, e_done("Purged", f"Deleted `{max(len(deleted) - 1, 0)}` message(s)."), delete_after=5)


async def setup(bot):
    await bot.add_cog(Moderation(bot))
