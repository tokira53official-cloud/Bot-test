import discord
from discord.ext import commands

from core.checks import admin_only
from core.embeds import e_done, e_err, e_info, e_prog, edit_embed, send_embed
from core.ptero import PteroError
from core.serverutil import guard
from core.service import dm
from core.views import ConfirmView


class PanelMgmt(commands.Cog):
    category = "admin"

    def __init__(self, bot):
        self.bot = bot

    @commands.command(brief="Panel-wide totals")
    @admin_only()
    async def panelstats(self, ctx):
        p = self.bot.ptero
        try:
            users, servers, nodes = await p.total("/users"), await p.total("/servers"), await p.total("/nodes")
        except PteroError as e:
            return await send_embed(ctx, e_err("Panel error", e.message[:300]), delete_after=10)
        c = await self.bot.db.counts()
        e = e_info("Panel stats")
        e.add_field(name="Panel", value=f"Users `{users}`\nServers `{servers}`\nNodes `{nodes}`")
        e.add_field(name="Via bot", value=f"Accounts `{c['accounts']}`\nServers `{c['servers']}`")
        e.add_field(name="By tier", value=f"Free `{c['free']}`\nPremium `{c['premium']}`\nVIP `{c['vip']}`")
        await send_embed(ctx, e)

    @commands.command(brief="List nodes and their allocation")
    @admin_only()
    async def nodes(self, ctx):
        ok, nodes = await guard(ctx, self.bot.ptero.list_nodes())
        if not ok:
            return
        lines = []
        for n in nodes[:15]:
            used = (n.get("allocated_resources") or {}).get("memory", 0)
            lines.append(f"{'🔧' if n.get('maintenance_mode') else '🟢'} **{n['name']}** (`{n['id']}`) • `{n.get('fqdn')}`\n"
                         f"└ RAM `{used}/{n.get('memory')} MB` • Disk limit `{n.get('disk')} MB`")
        await send_embed(ctx, e_info(f"Nodes ({len(nodes)})", "\n".join(lines) or "None"))

    @commands.command(brief="List locations")
    @admin_only()
    async def locations(self, ctx):
        ok, items = await guard(ctx, self.bot.ptero.list_locations())
        if ok:
            await send_embed(ctx, e_info("Locations", "\n".join(f"`{l['id']}` • **{l.get('short')}** — {l.get('long') or ''}" for l in items) or "None"))

    @commands.command(brief="List nests (with IDs)")
    @admin_only()
    async def nests(self, ctx):
        ok, items = await guard(ctx, self.bot.ptero.list_nests())
        if ok:
            await send_embed(ctx, e_info("Nests", "\n".join(f"`{n['id']}` • **{n['name']}**" for n in items) or "None"))

    @commands.command(brief="List eggs in a nest (with IDs)", usage="<nest_id>")
    @admin_only()
    async def eggs(self, ctx, nest_id: int):
        ok, items = await guard(ctx, self.bot.ptero.list_eggs(nest_id))
        if ok:
            await send_embed(ctx, e_info(f"Eggs in nest {nest_id}", "\n".join(f"`{x['id']}` • **{x['name']}**" for x in items)[:4000] or "None"))

    @commands.command(brief="Search panel servers by name", usage="<query>")
    @admin_only()
    async def findserver(self, ctx, *, query: str):
        ok, servers = await guard(ctx, self.bot.ptero.list_servers())
        if not ok:
            return
        q = query.lower()
        hits = [s for s in servers if q in s["name"].lower()][:15]
        lines = [f"{'⛔' if s.get('suspended') else '🟢'} **{s['name'][:30]}** • `{s['id']}` • panel user `{s.get('user')}`" for s in hits]
        await send_embed(ctx, e_info(f"Results for “{query[:40]}”", "\n".join(lines) or "No matches."))

    @commands.command(brief="List panel users (paged)", usage="[page]")
    @admin_only()
    async def panelusers(self, ctx, page: int = 1):
        ok, res = await guard(ctx, self.bot.ptero.list_users(max(page, 1), 10))
        if not ok:
            return
        users, pg = res
        lines = [f"`{u['id']}` • **{u['username']}** • {u['email']}{' • 👑' if u.get('root_admin') else ''}" for u in users]
        await send_embed(ctx, e_info(f"Panel users — page {pg.get('current_page', page)}/{pg.get('total_pages', 1)}",
                                     "\n".join(lines) or "Nothing on this page."))

    @commands.command(brief="Set RAM/disk/CPU of a server", usage="<server_id> <ram_mb> <disk_mb> <cpu_%>")
    @admin_only()
    async def setlimits(self, ctx, server_id: int, ram: int, disk: int, cpu: int):
        ok, _ = await guard(ctx, self.bot.ptero.update_build(server_id, memory=ram, disk=disk, cpu=cpu))
        if ok:
            await self.bot.db.audit(ctx.author.id, "setlimits", f"{server_id}:{ram}/{disk}/{cpu}")
            await send_embed(ctx, e_done("Limits updated", f"Server `{server_id}` → RAM `{ram} MB` • Disk `{disk} MB` • CPU `{cpu}%`"))

    @commands.command(brief="Apply a tier's specs to an existing server", usage="<server_id> <free|premium|vip>")
    @admin_only()
    async def setplan(self, ctx, server_id: int, tier: str):
        tier = tier.lower()
        if tier not in self.bot.cfg.tiers:
            return await send_embed(ctx, e_err("Invalid tier", "Use `free`, `premium` or `vip`."), delete_after=10)
        if not await self.bot.db.get_server(server_id):
            return await send_embed(ctx, e_err("Not tracked", "That server wasn't created by the bot."), delete_after=10)
        t = self.bot.cfg.tiers[tier]
        ok, _ = await guard(ctx, self.bot.ptero.update_build(
            server_id, memory=t.ram, disk=t.disk, cpu=t.cpu, databases=t.databases, backups=t.backups, allocations=t.allocations))
        if ok:
            await self.bot.db.set_server_tier(server_id, tier)
            await self.bot.db.audit(ctx.author.id, "setplan", f"{server_id}:{tier}")
            await send_embed(ctx, e_done("Plan applied", f"Server `{server_id}` is now **{t.label}**."))

    @commands.command(brief="Move a server to another linked member", usage="<server_id> <@member>")
    @admin_only()
    async def transfer(self, ctx, server_id: int, member: discord.Member):
        row = await self.bot.db.get_server(server_id)
        acct = await self.bot.db.get_account(member.id)
        if not row:
            return await send_embed(ctx, e_err("Not tracked", "That server wasn't created by the bot."), delete_after=10)
        if not acct:
            return await send_embed(ctx, e_err("Not linked", f"{member.mention} has no panel account."), delete_after=10)
        ok, _ = await guard(ctx, self.bot.ptero.update_details(server_id, user_id=acct["ptero_user_id"]))
        if ok:
            await self.bot.db.set_server_owner(server_id, member.id)
            await self.bot.db.audit(ctx.author.id, "transfer", f"{server_id}->{member.id}")
            await send_embed(ctx, e_done("Server transferred", f"**{row['name']}** now belongs to {member.mention}."))

    @commands.command(brief="Reinstall any server (panel side)", usage="<server_id>")
    @admin_only()
    async def reinstallserver(self, ctx, server_id: int):
        view = ConfirmView(ctx.author.id)
        msg = await send_embed(ctx, e_prog("Reinstall server?", f"Server `{server_id}` will be reinstalled."), view=view)
        await view.wait()
        if not view.value:
            return await edit_embed(msg, e_info("Cancelled"), view=None)
        ok, _ = await guard(ctx, self.bot.ptero.reinstall_app(server_id))
        if ok:
            await self.bot.db.audit(ctx.author.id, "reinstall", str(server_id))
            await edit_embed(msg, e_done("Reinstall started", f"Server `{server_id}`"), view=None)

    @commands.command(brief="Everything the bot knows about a user", usage="<@user|id>")
    @admin_only()
    async def lookup(self, ctx, user: discord.User):
        a = await self.bot.db.get_account(user.id)
        servers = await self.bot.db.user_servers(user.id)
        warns = await self.bot.db.get_warnings(user.id)
        e = e_info(f"Lookup — {user}")
        e.set_thumbnail(url=user.display_avatar.url)
        e.add_field(name="Discord", value=f"{user.mention}\n`{user.id}`")
        e.add_field(name="Panel", value=(f"`{a['username']}` (id `{a['ptero_user_id']}`)\n{a['email']}" + (" 👑" if a["panel_admin"] else "")) if a else "Not linked")
        e.add_field(name="Servers", value=f"`{len(servers)}`")
        e.add_field(name="Warnings", value=f"`{len(warns)}`")
        e.add_field(name="Blacklisted", value="Yes" if user.id in self.bot.blacklist else "No")
        e.add_field(name="Bot admin", value="Yes" if user.id in self.bot.admin_ids else "No")
        await send_embed(ctx, e)

    async def _bulk(self, ctx, member: discord.Member, suspend: bool):
        rows = await self.bot.db.user_servers(member.id)
        rows = [r for r in rows if bool(r["suspended"]) != suspend]
        if not rows:
            return await send_embed(ctx, e_err("Nothing to do", "No matching servers."), delete_after=10)
        fn = self.bot.ptero.suspend if suspend else self.bot.ptero.unsuspend
        done = []
        for r in rows:
            try:
                await fn(r["ptero_server_id"])
                await self.bot.db.set_suspended(r["ptero_server_id"], suspend)
                done.append(r["name"])
            except PteroError:
                continue
        await self.bot.db.audit(ctx.author.id, "suspendall" if suspend else "unsuspendall", f"{member.id}:{len(done)}")
        word = "suspended" if suspend else "unsuspended"
        note = (e_err if suspend else e_done)(f"Your servers were {word}", "\n".join(f"• {n}" for n in done)[:1500] or "—")
        sent = await dm(self.bot, member.id, note)
        await send_embed(ctx, e_done(f"{word.title()} {len(done)} server(s)",
                                     f"{member.mention}\n" + ("Owner notified by DM." if sent else "Couldn't DM the owner.")))

    @commands.command(brief="Suspend ALL of a member's servers (one DM)", usage="<@member>")
    @admin_only()
    async def suspendall(self, ctx, member: discord.Member):
        await self._bulk(ctx, member, True)

    @commands.command(brief="Unsuspend ALL of a member's servers", usage="<@member>")
    @admin_only()
    async def unsuspendall(self, ctx, member: discord.Member):
        await self._bulk(ctx, member, False)


async def setup(bot):
    await bot.add_cog(PanelMgmt(bot))
