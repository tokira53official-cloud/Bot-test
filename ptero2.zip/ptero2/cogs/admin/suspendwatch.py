"""Background watcher: DMs the owner when a server is suspended/unsuspended
(including suspensions made directly in the panel). Polls every 2 minutes."""
import logging

from discord.ext import commands, tasks

from core.ptero import PteroError
from core.service import notify_suspension

log = logging.getLogger("suspendwatch")


class SuspendWatch(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.poll.start()

    def cog_unload(self):
        self.poll.cancel()

    @tasks.loop(minutes=2)
    async def poll(self):
        try:
            panel = {s["id"]: s for s in await self.bot.ptero.list_servers()}
            baseline = await self.bot.db.kv_get("suspend_baseline")
            for r in await self.bot.db.tracked_servers():
                attrs = panel.get(r["ptero_server_id"])
                if attrs is None:
                    continue
                now = bool(attrs.get("suspended"))
                if now != r["suspended"]:
                    await self.bot.db.set_suspended(r["ptero_server_id"], now)
                    if baseline:  # first ever pass only syncs silently (no DM spam)
                        await notify_suspension(self.bot, attrs, now)
            if not baseline:
                await self.bot.db.kv_set("suspend_baseline", "1")
        except PteroError as e:
            log.warning("panel poll failed: %s", e.message)
        except Exception:
            log.exception("suspend watcher crashed")

    @poll.before_loop
    async def _before(self):
        await self.bot.wait_until_ready()


async def setup(bot):
    await bot.add_cog(SuspendWatch(bot))
