import time

import discord
from discord.ext import commands

from core.embeds import COL_GREEN, COL_RED, COL_YELLOW, e_info, e_main, make_embed, send_embed, ge


class General(commands.Cog):
    category = "general"

    def __init__(self, bot):
        self.bot = bot

    @commands.command(brief="Show WebSocket and REST latency")
    async def ping(self, ctx):
        ws = round(self.bot.latency * 1000)
        t = time.perf_counter()
        await self.bot.application_info()
        rest = round((time.perf_counter() - t) * 1000)
        worst = max(ws, rest)
        col = COL_GREEN if worst < 150 else COL_YELLOW if worst < 300 else COL_RED
        e = make_embed(f"{ge('ping', '🏓')} Pong!", f"**WebSocket:** `{ws} ms`\n**REST:** `{rest} ms`", col)
        await send_embed(ctx, e)

    @commands.command(brief="How long the bot has been online")
    async def uptime(self, ctx):
        s = int(time.time() - (self.bot.start_time or time.time()))
        d, s = divmod(s, 86400)
        h, s = divmod(s, 3600)
        m, s = divmod(s, 60)
        await send_embed(ctx, e_info("Uptime", f"`{d}d {h}h {m}m {s}s`"))

    @commands.command(brief="Get the bot invite link")
    async def invite(self, ctx):
        url = discord.utils.oauth_url(self.bot.user.id, permissions=discord.Permissions(
            manage_roles=True, manage_messages=True, send_messages=True, embed_links=True,
            attach_files=True, read_message_history=True), scopes=("bot",))
        await send_embed(ctx, e_info("Invite", f"[Click here to invite me]({url})"))

    @commands.command(brief="About this bot")
    async def about(self, ctx):
        owner_id = self.bot.cfg.owner_ids[0]
        e = e_main(f"{ge('info', 'ℹ️')} About {self.bot.cfg.bot_name}",
                   "Pterodactyl manager — link accounts and deploy servers from Discord.")
        try:
            owner = await self.bot.fetch_user(owner_id)
            e.set_thumbnail(url=owner.display_avatar.url)
        except discord.HTTPException:
            pass
        e.add_field(name="Owners", value=" ".join(f"<@{i}>" for i in self.bot.cfg.owner_ids), inline=False)
        e.add_field(name="Servers", value=str(len(self.bot.guilds)))
        e.add_field(name="Users", value=str(sum(g.member_count or 0 for g in self.bot.guilds)))
        e.add_field(name="Commands", value=str(len([c for c in self.bot.commands if not c.hidden])))
        await send_embed(ctx, e)


async def setup(bot):
    await bot.add_cog(General(bot))
