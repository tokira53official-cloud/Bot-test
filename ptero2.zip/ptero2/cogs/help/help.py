import discord
from discord import ui
from discord.ext import commands

from core.embeds import e_main, send_embed, ge

CATS = [("general", "General", "📡"), ("information", "Information", "ℹ️"), ("user", "User", "👤"),
        ("control", "Server", "🖥️"), ("premium", "Premium", "💎"), ("vip", "VIP", "👑"), ("admin", "Admin", "🛡️"), ("moderation", "Moderation", "🔨"), ("owner", "Owner", "🔒")]


class HelpView(ui.View):
    def __init__(self, bot, uid: int, cats):
        super().__init__(timeout=120)
        self.bot, self.uid, self.cats, self.message = bot, uid, cats, None
        home = ui.Button(label="Home", style=discord.ButtonStyle.primary, emoji="🏠", row=0)
        home.callback = self._make(None)
        self.add_item(home)
        for i, (key, label, emoji) in enumerate(cats, start=1):
            b = ui.Button(label=label, emoji=emoji, style=discord.ButtonStyle.secondary, row=i // 5)
            b.callback = self._make(key)
            self.add_item(b)

    def _commands(self, key):
        out = []
        for cog in self.bot.cogs.values():
            if getattr(cog, "category", None) != key:
                continue
            for c in cog.walk_commands():
                if isinstance(c, commands.Group) or (c.hidden and key != "owner"):
                    continue
                sig = f" {c.signature}" if c.signature else ""
                out.append(f"`{self.bot.cfg.prefix}{c.qualified_name}{sig}`\n└ {c.brief or 'No description'}")
        return out

    def page(self, key):
        prefix = self.bot.cfg.prefix
        if key is None:
            e = e_main(f"{ge('help', '📖')} {self.bot.cfg.bot_name} Help",
                       f"Prefix: `{prefix}` • Use the buttons below to browse categories.")
            for k, label, emoji in self.cats:
                e.add_field(name=f"{emoji} {label}", value=f"`{len(self._commands(k))}` commands", inline=True)
            return e
        label, emoji = next((l, em) for k, l, em in self.cats if k == key)
        cmds = self._commands(key)
        e = e_main(f"{emoji} {label} commands", "\n\n".join(cmds)[:4000] or "Nothing here yet.")
        return e

    def _make(self, key):
        async def callback(inter: discord.Interaction):
            if inter.user.id != self.uid:
                return
            await inter.response.edit_message(embed=self.page(key), view=self)
        return callback

    async def on_timeout(self):
        if self.message:
            try:
                await self.message.edit(view=None)
            except discord.HTTPException:
                pass


class Help(commands.Cog):
    category = "general"

    def __init__(self, bot):
        self.bot = bot

    @commands.command(brief="Interactive help menu")
    async def help(self, ctx):
        uid, cfg = ctx.author.id, self.bot.cfg
        is_owner = uid in cfg.owner_ids
        is_admin = is_owner or uid in self.bot.admin_ids
        cats = [c for c in CATS if (c[0] != "owner" or is_owner) and (c[0] != "admin" or is_admin)]
        view = HelpView(self.bot, uid, cats)
        view.message = await send_embed(ctx, view.page(None), view=view)


async def setup(bot):
    await bot.add_cog(Help(bot))
