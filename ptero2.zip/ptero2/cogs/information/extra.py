import platform
import time

import discord
from discord.ext import commands

from core.embeds import e_info, e_main, e_err, send_embed, ge
from core.serverutil import fmt_duration

try:
    import resource
except ImportError:  # not available everywhere
    resource = None


def _ms(v) -> str:
    return "n/a" if v != v or v == float("inf") else f"{round(v * 1000)} ms"


class Extra(commands.Cog):
    category = "information"

    def __init__(self, bot):
        self.bot = bot

    @commands.command(brief="Show someone's avatar", usage="[@member]")
    async def avatar(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        url = member.display_avatar.replace(size=1024).url
        e = e_main(f"{member.display_name}'s avatar", f"[Open full size]({url})")
        e.set_image(url=url)
        await send_embed(ctx, e)

    @commands.command(brief="Show the server icon")
    @commands.guild_only()
    async def servericon(self, ctx):
        if not ctx.guild.icon:
            return await send_embed(ctx, e_err("No icon", "This server has no icon."), delete_after=8)
        e = e_main(f"{ctx.guild.name} icon")
        e.set_image(url=ctx.guild.icon.replace(size=1024).url)
        await send_embed(ctx, e)

    @commands.command(brief="Member counts")
    @commands.guild_only()
    async def membercount(self, ctx):
        g = ctx.guild
        bots = sum(1 for m in g.members if m.bot)
        await send_embed(ctx, e_info("Member count", f"**Total:** `{g.member_count}`\n**Humans:** `{g.member_count - bots}`\n**Bots:** `{bots}`"))

    @commands.command(brief="Information about a role", usage="<@role>")
    @commands.guild_only()
    async def roleinfo(self, ctx, role: discord.Role):
        e = e_info(role.name)
        e.color = role.color
        e.add_field(name="ID", value=f"`{role.id}`")
        e.add_field(name="Members", value=f"`{len(role.members)}`")
        e.add_field(name="Position", value=f"`{role.position}`")
        e.add_field(name="Mentionable", value="Yes" if role.mentionable else "No")
        e.add_field(name="Hoisted", value="Yes" if role.hoist else "No")
        e.add_field(name="Created", value=f"<t:{int(role.created_at.timestamp())}:R>")
        await send_embed(ctx, e)

    @commands.command(brief="Information about a channel", usage="[#channel]")
    @commands.guild_only()
    async def channelinfo(self, ctx, channel: discord.TextChannel = None):
        c = channel or ctx.channel
        e = e_info(f"#{c.name}", c.topic or None)
        e.add_field(name="ID", value=f"`{c.id}`")
        e.add_field(name="Category", value=c.category.name if c.category else "None")
        e.add_field(name="Slowmode", value=f"`{c.slowmode_delay}s`")
        e.add_field(name="NSFW", value="Yes" if c.is_nsfw() else "No")
        e.add_field(name="Created", value=f"<t:{int(c.created_at.timestamp())}:R>")
        await send_embed(ctx, e)

    @commands.command(brief="Technical info about the bot")
    async def botinfo(self, ctx):
        b = self.bot
        e = e_info(f"{b.cfg.bot_name} — technical info")
        e.add_field(name="Python", value=f"`{platform.python_version()}`")
        e.add_field(name="discord.py", value=f"`{discord.__version__}`")
        e.add_field(name="Shards", value=f"`{b.shard_count}`")
        e.add_field(name="Latency", value=f"`{_ms(b.latency)}`")
        e.add_field(name="Uptime", value=f"`{fmt_duration((time.time() - (b.start_time or time.time())) * 1000)}`")
        if resource:
            e.add_field(name="Memory", value=f"`{resource.getrusage(resource.RUSAGE_SELF).ru_maxrss // 1024} MB`")
        await send_embed(ctx, e)

    @commands.command(brief="Latency and guild count per shard")
    async def shardinfo(self, ctx):
        lines = [f"Shard `{sid}` • `{_ms(lat)}` • `{sum(1 for g in self.bot.guilds if g.shard_id == sid)}` guild(s)"
                 for sid, lat in self.bot.latencies]
        await send_embed(ctx, e_info("Shards", "\n".join(lines) or "No shards."))

    @commands.command(brief="Show the command prefix")
    async def prefix(self, ctx):
        await send_embed(ctx, e_info("Prefix", f"My prefix is `{self.bot.cfg.prefix}` — try `{self.bot.cfg.prefix}help`."))

    @commands.command(brief="List the server's roles")
    @commands.guild_only()
    async def roles(self, ctx):
        roles = [r.mention for r in reversed(ctx.guild.roles) if r.name != "@everyone"]
        text = " ".join(roles)
        await send_embed(ctx, e_info(f"Roles ({len(roles)})", text[:4000] or "None"))


async def setup(bot):
    await bot.add_cog(Extra(bot))
