import discord
from discord.ext import commands

from core.embeds import e_err, e_info, e_main, send_embed, ge
from core.ptero import PteroError


class Information(commands.Cog):
    category = "information"

    def __init__(self, bot):
        self.bot = bot

    @commands.command(brief="Server information")
    @commands.guild_only()
    async def serverinfo(self, ctx):
        g = ctx.guild
        humans = sum(1 for m in g.members if not m.bot)
        e = e_main(f"{ge('info', 'ℹ️')} {g.name}")
        if g.icon:
            e.set_thumbnail(url=g.icon.url)
        e.add_field(name="Members", value=f"Humans `{humans}`\nBots `{g.member_count - humans}`")
        e.add_field(name="Channels", value=f"Text `{len(g.text_channels)}`\nVoice `{len(g.voice_channels)}`\nCategories `{len(g.categories)}`")
        e.add_field(name="Boost", value=f"Tier `{g.premium_tier}`\nBoosts `{g.premium_subscription_count}`")
        e.add_field(name="Verification", value=f"`{str(g.verification_level).title()}`")
        e.add_field(name="Created", value=f"<t:{int(g.created_at.timestamp())}:R>")
        await send_embed(ctx, e)

    @commands.command(brief="User information", usage="[@member]")
    async def userinfo(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        e = e_main(f"{ge('info', 'ℹ️')} {member.display_name}")
        e.set_thumbnail(url=member.display_avatar.url)
        e.add_field(name="ID", value=f"`{member.id}`")
        e.add_field(name="Created", value=f"<t:{int(member.created_at.timestamp())}:R>")
        if member.joined_at:
            e.add_field(name="Joined", value=f"<t:{int(member.joined_at.timestamp())}:R>")
        roles = [r.mention for r in reversed(member.roles) if r.name != "@everyone"]
        e.add_field(name=f"Roles ({len(roles)})", value=" ".join(roles[:15]) or "None", inline=False)
        await send_embed(ctx, e)

    @commands.command(brief="Panel + bot status")
    async def status(self, ctx):
        try:
            ms, nodes = await self.bot.ptero.ping()
            panel = f"Online • `{ms} ms` • `{nodes}` node(s)"
        except PteroError as ex:
            return await send_embed(ctx, e_err("Panel unreachable", ex.message[:300]))
        c = await self.bot.db.counts()
        e = e_info("Status")
        e.add_field(name="Panel", value=panel, inline=False)
        e.add_field(name="Linked accounts", value=str(c["accounts"]))
        e.add_field(name="Active servers", value=str(c["servers"]))
        await send_embed(ctx, e)


async def setup(bot):
    await bot.add_cog(Information(bot))
