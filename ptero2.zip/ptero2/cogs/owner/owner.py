import asyncio
import io
from typing import Dict, Tuple

import aiohttp
import discord
from discord.ext import commands

from core import embeds
from core.checks import owner_only
from core.embeds import e_done, e_err, e_info, e_main, e_prog, owner_reply, send_embed
from core.linkflow import start_link

# name -> (emoji_id, animated). Fill with your own emoji IDs for !syncemojis.
SYNC_EMOJIS: Dict[str, Tuple[int, bool]] = {}


class Owner(commands.Cog):
    category = "owner"

    def __init__(self, bot):
        self.bot = bot

    # ---------- admins ----------
    @commands.group(name="add", hidden=True, invoke_without_command=True, brief="Add things (see subcommands)")
    @owner_only()
    async def add(self, ctx):
        await owner_reply(ctx, e_info("Usage", f"`{ctx.prefix}add admin <@user|id>`"))

    @add.command(name="admin", hidden=True, brief="Make a user a bot admin", usage="<@user|id>")
    @owner_only()
    async def add_admin(self, ctx, user: discord.User):
        await self.bot.db.add_admin(user.id, ctx.author.id)
        self.bot.admin_ids.add(user.id)
        await self.bot.db.audit(ctx.author.id, "add_admin", str(user.id))
        await owner_reply(ctx, e_done("Admin added", f"{user.mention} can now use admin commands."))

    @commands.group(name="remove", hidden=True, invoke_without_command=True, brief="Remove things")
    @owner_only()
    async def remove(self, ctx):
        await owner_reply(ctx, e_info("Usage", f"`{ctx.prefix}remove admin <@user|id>`"))

    @remove.command(name="admin", hidden=True, brief="Remove a bot admin", usage="<@user|id>")
    @owner_only()
    async def remove_admin(self, ctx, user: discord.User):
        await self.bot.db.remove_admin(user.id)
        self.bot.admin_ids.discard(user.id)
        await self.bot.db.audit(ctx.author.id, "remove_admin", str(user.id))
        await owner_reply(ctx, e_done("Admin removed", f"{user.mention} is no longer an admin."))

    @commands.command(hidden=True, brief="List bot admins")
    @owner_only()
    async def admins(self, ctx):
        ids = sorted(self.bot.admin_ids)
        await owner_reply(ctx, e_info("Bot admins", "\n".join(f"<@{i}>" for i in ids) or "None"))

    @commands.command(hidden=True, brief="Create a panel ADMIN account (owners only)", usage="[@member]")
    @owner_only()
    async def linkadmin(self, ctx, member: discord.User = None):
        await start_link(ctx, member or ctx.author, admin=True)

    # ---------- blacklist ----------
    @commands.command(hidden=True, brief="Blacklist a user", usage="<@user|id> [reason]")
    @owner_only()
    async def blacklist(self, ctx, user: discord.User, *, reason: str = "No reason given"):
        if user.id in self.bot.cfg.owner_ids:
            return await owner_reply(ctx, e_err("Denied", "You can't blacklist an owner."))
        await self.bot.db.blacklist_user(user.id, reason)
        self.bot.blacklist.add(user.id)
        await owner_reply(ctx, e_done("Blacklisted", f"{user.mention}\n**Reason:** {reason}"))

    @commands.command(hidden=True, brief="Unblacklist a user", usage="<@user|id>")
    @owner_only()
    async def unblacklist(self, ctx, user: discord.User):
        await self.bot.db.unblacklist_user(user.id)
        self.bot.blacklist.discard(user.id)
        await owner_reply(ctx, e_done("Unblacklisted", user.mention))

    @commands.command(hidden=True, brief="Blacklist a server and leave it", usage="<guild_id>")
    @owner_only()
    async def blacklistserver(self, ctx, guild_id: int):
        await self.bot.db.blacklist_server(guild_id)
        self.bot.blacklisted_guilds.add(guild_id)
        g = self.bot.get_guild(guild_id)
        if g:
            await g.leave()
        await owner_reply(ctx, e_done("Server blacklisted", f"`{guild_id}`"))

    @commands.command(hidden=True, brief="Unblacklist a server", usage="<guild_id>")
    @owner_only()
    async def unblacklistserver(self, ctx, guild_id: int):
        await self.bot.db.unblacklist_server(guild_id)
        self.bot.blacklisted_guilds.discard(guild_id)
        await owner_reply(ctx, e_done("Server unblacklisted", f"`{guild_id}`"))

    @commands.command(hidden=True, brief="Show all blacklists")
    @owner_only()
    async def blacklisted(self, ctx):
        users = await self.bot.db.blacklisted_users()
        guilds = await self.bot.db.blacklisted_servers()
        e = e_info("Blacklist")
        e.add_field(name="Users", value="\n".join(f"<@{r['user_id']}> — {r['reason']}" for r in users)[:1000] or "None", inline=False)
        e.add_field(name="Servers", value="\n".join(f"`{r['guild_id']}`" for r in guilds)[:1000] or "None", inline=False)
        await owner_reply(ctx, e)

    # ---------- misc ----------
    @commands.command(hidden=True, brief="Announce in the command channel, or DM every linked user",
                      usage="<channel|dm> <message>")
    @owner_only()
    async def broadcast(self, ctx, mode: str, *, message: str):
        mode = mode.lower()
        if mode not in ("channel", "dm"):
            return await owner_reply(ctx, e_err("Invalid mode", "Use `channel` or `dm`."))
        if mode == "channel":
            ch = self.bot.get_channel(self.bot.cfg.command_channel_id) or ctx.channel
            await send_embed(ch, e_main("📢 Announcement", message))
            return await owner_reply(ctx, e_done("Broadcast sent", f"Posted in {ch.mention}."))
        ids = await self.bot.db.all_account_ids()
        await owner_reply(ctx, e_prog("Sending DMs…", f"`{len(ids)}` linked user(s). This is rate-limited, so it takes a while."))
        sent = failed = 0
        for uid in ids:
            try:
                user = self.bot.get_user(uid) or await self.bot.fetch_user(uid)
                await send_embed(user, e_main("📢 Announcement", message))
                sent += 1
            except discord.HTTPException:
                failed += 1
            await asyncio.sleep(1.2)
        await self.bot.db.audit(ctx.author.id, "broadcast_dm", f"{sent} sent / {failed} failed")
        await owner_reply(ctx, e_done("Broadcast finished", f"Delivered `{sent}` • Failed `{failed}` (DMs closed)."))

    @commands.command(hidden=True, brief="Leave all servers except whitelisted")
    @owner_only()
    async def leaveall(self, ctx):
        keep = set(self.bot.cfg.whitelist_guilds) | {self.bot.cfg.guild_id}
        n = 0
        for g in list(self.bot.guilds):
            if g.id not in keep:
                await g.leave()
                n += 1
        await owner_reply(ctx, e_done("Left servers", f"Left `{n}` server(s)."))

    @commands.command(hidden=True, brief="Reload all cogs")
    @owner_only()
    async def reload(self, ctx):
        done = []
        for ext in [e for e in list(self.bot.extensions) if e.startswith("cogs.")]:
            try:
                await self.bot.reload_extension(ext)
                done.append(ext)
            except Exception as ex:
                return await owner_reply(ctx, e_err("Reload failed", f"`{ext}`: {ex}"[:500]))
        await owner_reply(ctx, e_done("Reloaded", f"`{len(done)}` cog(s)."))

    @commands.command(hidden=True, brief="Database counters")
    @owner_only()
    async def stats(self, ctx):
        c = await self.bot.db.counts()
        e = e_info("Stats")
        e.add_field(name="Accounts", value=str(c["accounts"]))
        e.add_field(name="Active servers", value=str(c["servers"]))
        e.add_field(name="By tier", value=f"Free `{c['free']}`\nPremium `{c['premium']}`\nVIP `{c['vip']}`")
        await owner_reply(ctx, e)

    @commands.command(hidden=True, brief="Load this server's custom emojis")
    @owner_only()
    async def useemojis(self, ctx):
        guild = ctx.guild or self.bot.get_guild(self.bot.cfg.guild_id)
        if not guild:
            return await owner_reply(ctx, e_err("No server", "Run this in your server."))
        for em in guild.emojis:
            embeds.EMOJI_MAP[em.name] = f"<{'a' if em.animated else ''}:{em.name}:{em.id}>"
        await owner_reply(ctx, e_done("Emojis loaded", f"`{len(guild.emojis)}` emoji(s) mapped."))

    @commands.command(hidden=True, brief="Upload the hardcoded emoji list", usage="[guild_id]")
    @owner_only()
    async def syncemojis(self, ctx, guild_id: int = 0):
        guild = self.bot.get_guild(guild_id) if guild_id else (ctx.guild or self.bot.get_guild(self.bot.cfg.guild_id))
        if not guild or not SYNC_EMOJIS:
            return await owner_reply(ctx, e_err("Nothing to do", "No target server or `SYNC_EMOJIS` is empty."))
        ok = 0
        async with aiohttp.ClientSession() as s:
            for name, (eid, animated) in SYNC_EMOJIS.items():
                ext = "gif" if animated else "png"
                try:
                    async with s.get(f"https://cdn.discordapp.com/emojis/{eid}.{ext}") as r:
                        data = await r.read()
                    await guild.create_custom_emoji(name=name, image=data)
                    ok += 1
                except discord.HTTPException:
                    continue
        await owner_reply(ctx, e_done("Emojis synced", f"`{ok}/{len(SYNC_EMOJIS)}` uploaded to **{guild.name}**."))


async def setup(bot):
    await bot.add_cog(Owner(bot))
