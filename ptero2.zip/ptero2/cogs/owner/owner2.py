import io
import json
import os
import sys
import time

import discord
from discord.ext import commands

from core.checks import owner_only
from core.embeds import e_done, e_err, e_info, e_main, e_prog, edit_embed, owner_reply, send_embed
from core.ptero import PteroError
from core.service import dm as send_dm
from core.views import ConfirmView


class Owner2(commands.Cog):
    category = "owner"

    def __init__(self, bot):
        self.bot = bot

    @commands.command(hidden=True, brief="Recent audit log entries", usage="[count]")
    @owner_only()
    async def auditlog(self, ctx, count: int = 15):
        rows = await self.bot.db.audit_recent(max(1, min(count, 30)))
        lines = [f"<t:{int(r['at'].timestamp())}:R> <@{r['actor']}> `{r['action']}` {(r['detail'] or '')[:40]}" for r in rows]
        await owner_reply(ctx, e_info("Audit log", "\n".join(lines)[:4000] or "Empty."))

    @commands.command(hidden=True, brief="Toggle maintenance mode (blocks non-owners)", usage="<on|off>")
    @owner_only()
    async def maintenance(self, ctx, mode: str):
        mode = mode.lower()
        if mode not in ("on", "off"):
            return await owner_reply(ctx, e_err("Invalid", "Use `on` or `off`."))
        self.bot.maintenance = mode == "on"
        await self.bot.db.kv_set("maintenance", "1" if self.bot.maintenance else "0")
        await owner_reply(ctx, e_done("Maintenance", f"Maintenance mode is **{mode.upper()}**."))

    @commands.command(hidden=True, brief="Force-delete any panel server", usage="<server_id>")
    @owner_only()
    async def forcedelete(self, ctx, server_id: int):
        view = ConfirmView(ctx.author.id)
        msg = await send_embed(ctx.author if ctx.guild else ctx, e_prog("Force delete?", f"Server `{server_id}` — cannot be undone."), view=view)
        await view.wait()
        if not view.value:
            return await edit_embed(msg, e_info("Cancelled"), view=None)
        try:
            await self.bot.ptero.delete_server(server_id, force=True)
        except PteroError as e:
            return await edit_embed(msg, e_err("Panel error", e.message[:300]), view=None)
        await self.bot.db.mark_deleted(server_id)
        await self.bot.db.audit(ctx.author.id, "forcedelete", str(server_id))
        await edit_embed(msg, e_done("Force deleted", f"Server `{server_id}`"), view=None)

    @commands.command(hidden=True, brief="Delete ALL servers of a user", usage="<@user|id>")
    @owner_only()
    async def purgeuser(self, ctx, user: discord.User):
        rows = await self.bot.db.user_servers(user.id)
        if not rows:
            return await owner_reply(ctx, e_err("Nothing to do", f"{user.mention} has no active servers."))
        view = ConfirmView(ctx.author.id)
        msg = await send_embed(ctx.author if ctx.guild else ctx, e_prog("Delete everything?", f"{len(rows)} server(s) of {user.mention} will be deleted."), view=view)
        await view.wait()
        if not view.value:
            return await edit_embed(msg, e_info("Cancelled"), view=None)
        n = 0
        for r in rows:
            try:
                await self.bot.ptero.delete_server(r["ptero_server_id"])
            except PteroError as e:
                if e.status != 404:
                    continue
            await self.bot.db.mark_deleted(r["ptero_server_id"])
            n += 1
        await self.bot.db.audit(ctx.author.id, "purgeuser", f"{user.id}:{n}")
        await edit_embed(msg, e_done("User purged", f"Deleted `{n}/{len(rows)}` server(s)."), view=None)

    @commands.command(hidden=True, brief="List servers the bot is in")
    @owner_only()
    async def guilds(self, ctx):
        gs = sorted(self.bot.guilds, key=lambda g: g.member_count or 0, reverse=True)[:25]
        lines = [f"**{g.name[:30]}** • `{g.id}` • `{g.member_count}` members" for g in gs]
        await owner_reply(ctx, e_info(f"Guilds ({len(self.bot.guilds)})", "\n".join(lines) or "None"))

    @commands.command(hidden=True, brief="Make the bot say something", usage="<text>")
    @owner_only()
    async def say(self, ctx, *, text: str):
        try:
            await ctx.message.delete()
        except discord.HTTPException:
            pass
        await ctx.send(text, allowed_mentions=discord.AllowedMentions.none())

    @commands.command(name="dm", hidden=True, brief="DM a user as the owners", usage="<@user|id> <message>")
    @owner_only()
    async def dm_cmd(self, ctx, user: discord.User, *, message: str):
        ok = await send_dm(self.bot, user.id, e_main("📩 Message from the owners", message[:1800]))
        await owner_reply(ctx, e_done("Sent", user.mention) if ok else e_err("Failed", f"{user.mention} has DMs closed."))

    @commands.command(hidden=True, brief="Shut the bot down")
    @owner_only()
    async def shutdown(self, ctx):
        await owner_reply(ctx, e_done("Shutting down", "Goodbye."))
        await self.bot.close()

    @commands.command(hidden=True, brief="Restart the bot process")
    @owner_only()
    async def restartbot(self, ctx):
        await owner_reply(ctx, e_prog("Restarting…", "Be right back."))
        await self.bot.close()
        os.execv(sys.executable, [sys.executable] + sys.argv)

    @commands.command(hidden=True, brief="DM yourself a JSON export of the database")
    @owner_only()
    async def exportdata(self, ctx):
        data = await self.bot.db.export_all()
        buf = io.BytesIO(json.dumps(data, default=str, indent=2).encode("utf-8"))
        try:
            await ctx.author.send("Database export (contains emails, never passwords):",
                                  file=discord.File(buf, filename=f"export-{int(time.time())}.json"))
        except discord.Forbidden:
            return await send_embed(ctx, e_err("DMs closed", "Open your DMs — exports are never posted in channels."), delete_after=10)
        if ctx.guild:
            await send_embed(ctx, e_done("Export sent", "Check your DMs."), delete_after=8)


async def setup(bot):
    await bot.add_cog(Owner2(bot))
