from discord.ext import commands

from core.service import claim


class Premium(commands.Cog):
    category = "premium"

    def __init__(self, bot):
        self.bot = bot

    @commands.command(brief="Create a premium server (Premium role)", usage="<js|py|mc>")
    async def premium(self, ctx, kind: str):
        await claim(ctx, "premium", kind)


async def setup(bot):
    await bot.add_cog(Premium(bot))
