import discord
from discord.ext import commands

from core.embeds import e_done, e_err, e_info, e_main, send_embed, ge
from core.linkflow import EMAIL_RE, clean_username
from core.service import dm
from core.serverutil import guard


class Account(commands.Cog):
    category = "user"

    def __init__(self, bot):
        self.bot = bot

    @commands.command(brief="Show the specs of every tier")
    async def tiers(self, ctx):
        counts = await self.bot.db.counts()
        e = e_main(f"{ge('gem', '💎')} Tiers")
        for key, t in self.bot.cfg.tiers.items():
            limit = f"{counts[key]}/{t.global_limit}" if t.global_limit else f"{counts[key]}/∞"
            e.add_field(
                name=f"{'🟢' if t.enabled else '🔴'} {t.label}",
                value=(f"RAM `{t.ram} MB` • Disk `{t.disk} MB` • CPU `{t.cpu}%`\n"
                       f"DBs `{t.databases}` • Backups `{t.backups}` • Ports `{t.allocations}`\n"
                       f"Per user `{t.max_per_user or '∞'}` • Global `{limit}`"),
                inline=False)
        await send_embed(ctx, e)

    @commands.command(brief="Your server usage vs. your limits")
    async def quota(self, ctx):
        lines = []
        for key, t in self.bot.cfg.tiers.items():
            n = await self.bot.db.count_user_tier(ctx.author.id, key)
            lines.append(f"{'🟢' if t.enabled else '🔴'} **{t.label}** — `{n}/{t.max_per_user or '∞'}`")
        await send_embed(ctx, e_info("Your quota", "\n".join(lines)))

    @commands.command(brief="Your bot usage statistics")
    async def mystats(self, ctx):
        s = await self.bot.db.get_stats(ctx.author.id)
        a = await self.bot.db.get_account(ctx.author.id)
        e = e_info("Your stats")
        e.add_field(name="Commands used", value=f"`{s['commands_used'] if s else 0}`")
        e.add_field(name="Servers created", value=f"`{s['servers_created'] if s else 0}`")
        if a:
            e.add_field(name="Linked since", value=f"<t:{int(a['created_at'].timestamp())}:R>")
        await send_embed(ctx, e)

    @commands.command(brief="Your account, roles and permissions")
    async def whoami(self, ctx):
        bot, cfg = self.bot, self.bot.cfg
        a = await bot.db.get_account(ctx.author.id)
        member = ctx.author if ctx.guild else None
        roles = [t.label for t in cfg.tiers.values()
                 if member and t.role_id and any(r.id == t.role_id for r in getattr(member, "roles", []))]
        rank = "Owner" if ctx.author.id in cfg.owner_ids else "Admin" if ctx.author.id in bot.admin_ids else "User"
        e = e_info(f"{ctx.author.display_name}")
        e.set_thumbnail(url=ctx.author.display_avatar.url)
        e.add_field(name="Rank", value=f"`{rank}`")
        e.add_field(name="Tier roles", value=", ".join(roles) or "None")
        e.add_field(name="Panel account", value=(f"`{a['username']}`" + (" (admin)" if a["panel_admin"] else "")) if a else "Not linked")
        await send_embed(ctx, e)

    @commands.command(brief="Top users by servers created")
    async def leaderboard(self, ctx):
        rows = await self.bot.db.leaderboard(10)
        medals = ["🥇", "🥈", "🥉"] + ["▫️"] * 7
        lines = [f"{medals[i]} <@{r['discord_id']}> — `{r['servers_created']}` servers • `{r['commands_used']}` cmds"
                 for i, r in enumerate(rows)]
        await send_embed(ctx, e_main("🏆 Leaderboard", "\n".join(lines) or "No data yet."))

    @commands.command(brief="Change your panel email", usage="<new_email>")
    async def changeemail(self, ctx, email: str):
        try:
            await ctx.message.delete()
        except discord.HTTPException:
            pass
        email = email.strip().lower()
        a = await self.bot.db.get_account(ctx.author.id)
        if not a:
            return await send_embed(ctx, e_err("Not linked", f"Use `{ctx.prefix}link` first."), delete_after=10)
        if not EMAIL_RE.match(email):
            return await send_embed(ctx, e_err("Invalid email", "Please give a valid address."), delete_after=10)
        ok, _ = await guard(ctx, self.bot.ptero.update_user(a["ptero_user_id"], email=email))
        if ok:
            await self.bot.db.update_account(ctx.author.id, email=email)
            await send_embed(ctx, e_done("Email updated", f"Your panel email is now `{email}`."), delete_after=15)

    @commands.command(brief="Change your panel username", usage="<new_username>")
    async def changeusername(self, ctx, username: str):
        a = await self.bot.db.get_account(ctx.author.id)
        if not a:
            return await send_embed(ctx, e_err("Not linked", f"Use `{ctx.prefix}link` first."), delete_after=10)
        name = clean_username(username, "", ctx.author.id)
        ok, _ = await guard(ctx, self.bot.ptero.update_user(a["ptero_user_id"], username=name))
        if ok:
            await self.bot.db.update_account(ctx.author.id, username=name)
            await send_embed(ctx, e_done("Username updated", f"Your panel username is now `{name}`."))

    @commands.command(brief="Send feedback to the bot owners", usage="<message>")
    @commands.cooldown(1, 300, commands.BucketType.user)
    async def feedback(self, ctx, *, message: str):
        e = e_main("📝 New feedback", message[:1500])
        e.add_field(name="From", value=f"{ctx.author.mention} (`{ctx.author.id}`)")
        sent = 0
        for oid in self.bot.cfg.owner_ids:
            if await dm(self.bot, oid, e):
                sent += 1
        await send_embed(ctx, e_done("Thanks!", "Your feedback was sent to the owners.") if sent
                         else e_err("Couldn't deliver", "The owners' DMs are closed."), delete_after=10)


async def setup(bot):
    await bot.add_cog(Account(bot))
