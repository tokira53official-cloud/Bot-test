import asyncio

import discord
from discord import ui
from discord.ext import commands

from core.embeds import e_done, e_err, e_main, ge, send_embed
from core.ptero import PteroError
from core.service import server_url

ICON = {"running": "🟢", "starting": "🟡", "stopping": "🟠", "offline": "🔴"}


class ManageView(ui.View):
    def __init__(self, bot, uid: int, rows, index: int = 0):
        super().__init__(timeout=180)
        self.bot, self.uid, self.rows, self.index = bot, uid, list(rows), index
        self.confirming = False
        self.notice = ""
        self.message = None
        self._refresh()

    @property
    def row(self):
        return self.rows[self.index]

    def _refresh(self):
        self.clear_items()
        if self.confirming:
            yes = ui.Button(label="Yes, delete it", style=discord.ButtonStyle.danger, row=0)
            yes.callback = self.do_delete
            no = ui.Button(label="Cancel", style=discord.ButtonStyle.secondary, row=0)
            no.callback = self.cancel_delete
            self.add_item(yes)
            self.add_item(no)
            return
        if len(self.rows) > 1:
            sel = ui.Select(placeholder="Choose a server", row=0, options=[
                discord.SelectOption(label=r["name"][:100], value=str(i), default=(i == self.index),
                                     description=f"ID {r['ptero_server_id']} • {r['kind'].upper()}")
                for i, r in enumerate(self.rows[:25])])
            sel.callback = self.on_select
            self.add_item(sel)
        for label, style, cb, row in (
                ("Start", discord.ButtonStyle.success, self.start_btn, 1),
                ("Stop", discord.ButtonStyle.danger, self.stop_btn, 1),
                ("Restart", discord.ButtonStyle.primary, self.restart, 1),
                ("Delete", discord.ButtonStyle.danger, self.ask_delete, 2),
                ("Refresh", discord.ButtonStyle.secondary, self.refresh_btn, 2)):
            b = ui.Button(label=label, style=style, row=row)
            b.callback = cb
            self.add_item(b)

    async def build(self) -> discord.Embed:
        r = self.row
        state = usage = None
        try:
            st = await self.bot.ptero.state(r["identifier"])
            state = "suspended" if st.get("is_suspended") else st.get("current_state", "unknown")
            res = st.get("resources", {})
            usage = f"RAM `{res.get('memory_bytes', 0) // 1048576} MB` • CPU `{res.get('cpu_absolute', 0):.0f}%`"
        except PteroError as e:
            self.notice = self.notice or f"⚠️ {e.message[:200]}"
        e = e_main(f"{ge('gear', '⚙️')} {r['name']}", self.notice or None)
        e.add_field(name="Status", value=f"{ICON.get(state, '⚪')} `{state or 'unknown'}`")
        e.add_field(name="Server", value=f"ID `{r['ptero_server_id']}`\n{r['kind'].upper()} • {r['tier'].title()}")
        if usage:
            e.add_field(name="Usage", value=usage)
        e.add_field(name="Panel", value=f"[Open console]({server_url(self.bot.cfg, r['identifier'])})", inline=False)
        return e

    async def _push(self, inter):
        self._refresh()
        await inter.edit_original_response(embed=await self.build(), view=self)

    def _ok(self, inter) -> bool:
        return inter.user.id == self.uid

    async def _power(self, inter, signal: str):
        if not self._ok(inter):
            return
        await inter.response.defer()
        try:
            await self.bot.ptero.power(self.row["identifier"], signal)
            self.notice = f"✅ Sent `{signal}` signal."
            await asyncio.sleep(2)
        except PteroError as e:
            self.notice = f"⚠️ {e.message[:200]}"
        await self._push(inter)
        self.notice = ""

    async def start_btn(self, inter): await self._power(inter, "start")
    async def stop_btn(self, inter): await self._power(inter, "stop")
    async def restart(self, inter): await self._power(inter, "restart")

    async def refresh_btn(self, inter):
        if not self._ok(inter):
            return
        await inter.response.defer()
        await self._push(inter)

    async def on_select(self, inter):
        if not self._ok(inter):
            return
        self.index = int(inter.data["values"][0])
        await inter.response.defer()
        await self._push(inter)

    async def ask_delete(self, inter):
        if not self._ok(inter):
            return
        self.confirming = True
        await inter.response.defer()
        self._refresh()
        emb = e_main(f"{ge('warn', '⚠️')} Delete {self.row['name']}?", "This permanently deletes the server and its files.")
        await inter.edit_original_response(embed=emb, view=self)

    async def cancel_delete(self, inter):
        if not self._ok(inter):
            return
        self.confirming = False
        await inter.response.defer()
        await self._push(inter)

    async def do_delete(self, inter):
        if not self._ok(inter):
            return
        await inter.response.defer()
        r = self.row
        try:
            await self.bot.ptero.delete_server(r["ptero_server_id"])
        except PteroError as e:
            if e.status != 404:
                self.confirming = False
                self.notice = f"⚠️ {e.message[:200]}"
                return await self._push(inter)
        await self.bot.db.mark_deleted(r["ptero_server_id"])
        await self.bot.db.audit(inter.user.id, "delete", str(r["ptero_server_id"]))
        self.stop()
        await inter.edit_original_response(embed=e_done("Server deleted", r["name"]), view=None)

    async def on_timeout(self):
        if self.message:
            try:
                await self.message.edit(view=None)
            except discord.HTTPException:
                pass


class Manage(commands.Cog):
    category = "user"

    def __init__(self, bot):
        self.bot = bot

    @commands.command(brief="Manage your servers with buttons (start/stop/restart/delete)", usage="[server_id]")
    async def manage(self, ctx, server_id: int = None):
        cfg = self.bot.cfg
        is_admin = ctx.author.id in cfg.owner_ids or ctx.author.id in self.bot.admin_ids
        if server_id is not None:
            row = await self.bot.db.get_server(server_id)
            if not row or (row["discord_id"] != ctx.author.id and not is_admin):
                return await send_embed(ctx, e_err("Not found", "That server isn't yours."), delete_after=10)
            rows = [row]
        else:
            rows = await self.bot.db.user_servers(ctx.author.id)
            if not rows:
                return await send_embed(ctx, e_err("No servers", f"You have none. Try `{ctx.prefix}free js`."), delete_after=10)
        view = ManageView(self.bot, ctx.author.id, rows)
        view.message = await send_embed(ctx, await view.build(), view=view)


async def setup(bot):
    await bot.add_cog(Manage(bot))
