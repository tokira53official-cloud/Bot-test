import discord
from discord.ext import commands

from core.embeds import e_done, e_err, e_info, e_prog, edit_embed, send_embed, ge
from core.serverutil import fmt_bytes, fmt_duration, guard, resolve_server, ts
from core.service import server_url
from core.views import ConfirmView


class ServerControl(commands.Cog):
    category = "control"

    def __init__(self, bot):
        self.bot = bot

    async def _power(self, ctx, server_id: int, signal: str):
        row = await resolve_server(ctx, server_id)
        if not row:
            return
        ok, _ = await guard(ctx, self.bot.ptero.power(row["identifier"], signal))
        if ok:
            await send_embed(ctx, e_done(f"{signal.title()} signal sent", f"**{row['name']}** (`{server_id}`)"))

    @commands.command(name="start", brief="Start a server", usage="<server_id>")
    async def cmd_start(self, ctx, server_id: int):
        await self._power(ctx, server_id, "start")

    @commands.command(name="stop", brief="Stop a server", usage="<server_id>")
    async def cmd_stop(self, ctx, server_id: int):
        await self._power(ctx, server_id, "stop")

    @commands.command(name="restart", brief="Restart a server", usage="<server_id>")
    async def cmd_restart(self, ctx, server_id: int):
        await self._power(ctx, server_id, "restart")

    @commands.command(name="kill", brief="Force-kill a server process", usage="<server_id>")
    async def cmd_kill(self, ctx, server_id: int):
        await self._power(ctx, server_id, "kill")

    @commands.command(brief="Send a console command to a server", usage="<server_id> <command>")
    async def sendcmd(self, ctx, server_id: int, *, command: str):
        row = await resolve_server(ctx, server_id)
        if not row:
            return
        ok, _ = await guard(ctx, self.bot.ptero.send_command(row["identifier"], command))
        if ok:
            await send_embed(ctx, e_done("Command sent", f"`{command[:200]}` → **{row['name']}**"))

    @commands.command(brief="Live CPU / RAM / disk / network of a server", usage="<server_id>")
    async def serverstatus(self, ctx, server_id: int):
        row = await resolve_server(ctx, server_id)
        if not row:
            return
        ok, st = await guard(ctx, self.bot.ptero.state(row["identifier"]))
        if not ok:
            return
        res = st.get("resources", {})
        e = e_info(f"{row['name']} — live status")
        e.add_field(name="State", value=f"`{'suspended' if st.get('is_suspended') else st.get('current_state', '?')}`")
        e.add_field(name="CPU", value=f"`{res.get('cpu_absolute', 0):.1f}%`")
        e.add_field(name="RAM", value=f"`{fmt_bytes(res.get('memory_bytes'))}`")
        e.add_field(name="Disk", value=f"`{fmt_bytes(res.get('disk_bytes'))}`")
        e.add_field(name="Network", value=f"↓ `{fmt_bytes(res.get('network_rx_bytes'))}`\n↑ `{fmt_bytes(res.get('network_tx_bytes'))}`")
        e.add_field(name="Uptime", value=f"`{fmt_duration(res.get('uptime'))}`")
        await send_embed(ctx, e)

    @commands.command(brief="Rename a server", usage="<server_id> <new name>")
    async def rename(self, ctx, server_id: int, *, name: str):
        row = await resolve_server(ctx, server_id)
        if not row:
            return
        name = name.strip()[:60]
        ok, _ = await guard(ctx, self.bot.ptero.rename(row["identifier"], name))
        if ok:
            await self.bot.db.rename_server(server_id, name)
            await send_embed(ctx, e_done("Renamed", f"**{row['name']}** → **{name}**"))

    @commands.command(brief="Reinstall a server (wipes files!)", usage="<server_id>")
    async def reinstall(self, ctx, server_id: int):
        row = await resolve_server(ctx, server_id)
        if not row:
            return
        view = ConfirmView(ctx.author.id)
        msg = await send_embed(ctx, e_prog("Reinstall server?", f"**{row['name']}** will be reinstalled. Files may be overwritten."), view=view)
        await view.wait()
        if not view.value:
            return await edit_embed(msg, e_info("Cancelled"), view=None)
        ok, _ = await guard(ctx, self.bot.ptero.reinstall_client(row["identifier"]))
        if ok:
            await edit_embed(msg, e_done("Reinstall started", row["name"]), view=None)

    @commands.command(brief="Show the IP:port of a server", usage="<server_id>")
    async def address(self, ctx, server_id: int):
        row = await resolve_server(ctx, server_id)
        if not row:
            return
        ok, items = await guard(ctx, self.bot.ptero.network(row["identifier"]))
        if not ok:
            return
        lines = [f"{'⭐' if a.get('is_default') else '•'} `{a.get('ip_alias') or a.get('ip')}:{a.get('port')}`" for a in items]
        await send_embed(ctx, e_info(f"{row['name']} — addresses", "\n".join(lines) or "No allocations."))

    @commands.command(brief="Create a backup", usage="<server_id> [name]")
    async def backup(self, ctx, server_id: int, *, name: str = ""):
        row = await resolve_server(ctx, server_id)
        if not row:
            return
        ok, b = await guard(ctx, self.bot.ptero.create_backup(row["identifier"], name[:60]))
        if ok:
            await send_embed(ctx, e_done("Backup started", f"**{row['name']}**\nUUID `{b.get('uuid', '?')}`"))

    @commands.command(brief="List backups", usage="<server_id>")
    async def backups(self, ctx, server_id: int):
        row = await resolve_server(ctx, server_id)
        if not row:
            return
        ok, items = await guard(ctx, self.bot.ptero.list_backups(row["identifier"]))
        if not ok:
            return
        lines = [f"{'🔒' if b.get('is_locked') else '💾'} **{b.get('name', '?')[:30]}** • {fmt_bytes(b.get('bytes'))} • "
                 f"<t:{ts(b.get('created_at'))}:R>\n`{b.get('uuid')}`" for b in items[:10]]
        await send_embed(ctx, e_info(f"{row['name']} — backups ({len(items)})", "\n".join(lines) or "No backups."))

    @commands.command(brief="Delete a backup", usage="<server_id> <backup_uuid>")
    async def deletebackup(self, ctx, server_id: int, uuid: str):
        row = await resolve_server(ctx, server_id)
        if not row:
            return
        view = ConfirmView(ctx.author.id)
        msg = await send_embed(ctx, e_prog("Delete backup?", f"`{uuid}`"), view=view)
        await view.wait()
        if not view.value:
            return await edit_embed(msg, e_info("Cancelled"), view=None)
        ok, _ = await guard(ctx, self.bot.ptero.delete_backup(row["identifier"], uuid))
        if ok:
            await edit_embed(msg, e_done("Backup deleted", f"`{uuid}`"), view=None)

    @commands.command(brief="Browse a server's files", usage="<server_id> [directory]")
    async def files(self, ctx, server_id: int, *, directory: str = "/"):
        row = await resolve_server(ctx, server_id)
        if not row:
            return
        ok, items = await guard(ctx, self.bot.ptero.list_files(row["identifier"], directory))
        if not ok:
            return
        items.sort(key=lambda f: (f.get("is_file", True), f.get("name", "").lower()))
        lines = [f"📄 `{f['name']}` • {fmt_bytes(f.get('size'))}" if f.get("is_file") else f"📁 `{f['name']}/`" for f in items[:40]]
        more = f"\n…and {len(items) - 40} more" if len(items) > 40 else ""
        await send_embed(ctx, e_info(f"{row['name']} — {directory}", ("\n".join(lines) + more) or "Empty."))

    @commands.command(brief="Show startup command + variables", usage="<server_id>")
    async def startup(self, ctx, server_id: int):
        row = await resolve_server(ctx, server_id)
        if not row:
            return
        ok, res = await guard(ctx, self.bot.ptero.startup_vars(row["identifier"]))
        if not ok:
            return
        meta, variables = res
        lines = [f"{'✏️' if v.get('is_editable') else '🔒'} `{v.get('env_variable')}` = `{str(v.get('server_value') or v.get('default_value') or '')[:40]}`"
                 for v in variables[:25]]
        cmd = str(meta.get("startup_command", ""))[:500]
        await send_embed(ctx, e_info(f"{row['name']} — startup", f"```{cmd}```\n" + ("\n".join(lines) or "No variables.")))

    @commands.command(brief="Set an editable startup variable", usage="<server_id> <KEY> <value>")
    async def setvar(self, ctx, server_id: int, key: str, *, value: str):
        row = await resolve_server(ctx, server_id)
        if not row:
            return
        ok, _ = await guard(ctx, self.bot.ptero.set_variable(row["identifier"], key.upper(), value))
        if ok:
            await send_embed(ctx, e_done("Variable updated", f"`{key.upper()}` = `{value[:100]}`\nRestart the server to apply."))

    @commands.command(brief="List a server's databases", usage="<server_id>")
    async def databases(self, ctx, server_id: int):
        row = await resolve_server(ctx, server_id)
        if not row:
            return
        ok, items = await guard(ctx, self.bot.ptero.list_databases(row["identifier"]))
        if not ok:
            return
        lines = [f"🗄️ `{d.get('name')}` • user `{d.get('username')}` • `{d.get('host', {}).get('address')}:{d.get('host', {}).get('port')}`" for d in items]
        await send_embed(ctx, e_info(f"{row['name']} — databases", "\n".join(lines) or "No databases."))

    @commands.command(brief="List a server's schedules", usage="<server_id>")
    async def schedules(self, ctx, server_id: int):
        row = await resolve_server(ctx, server_id)
        if not row:
            return
        ok, items = await guard(ctx, self.bot.ptero.list_schedules(row["identifier"]))
        if not ok:
            return
        lines = []
        for s in items[:15]:
            c = s.get("cron", {})
            cron = f"{c.get('minute')} {c.get('hour')} {c.get('day_of_month')} {c.get('month')} {c.get('day_of_week')}"
            lines.append(f"{'🟢' if s.get('is_active') else '🔴'} **{s.get('name')}** • `{cron}` • next <t:{ts(s.get('next_run_at'))}:R>")
        await send_embed(ctx, e_info(f"{row['name']} — schedules", "\n".join(lines) or "No schedules."))

    @commands.command(name="server", brief="Detailed info about one server", usage="<server_id>")
    async def server_cmd(self, ctx, server_id: int):
        row = await resolve_server(ctx, server_id)
        if not row:
            return
        ok, a = await guard(ctx, self.bot.ptero.get_server(server_id))
        if not ok:
            return
        lim = a.get("limits", {})
        e = e_info(row["name"])
        e.add_field(name="Owner", value=f"<@{row['discord_id']}>")
        e.add_field(name="Type / Tier", value=f"{row['kind'].upper()} • {row['tier'].title()}")
        e.add_field(name="Suspended", value="⛔ Yes" if a.get("suspended") else "No")
        e.add_field(name="Limits", value=f"RAM `{lim.get('memory')} MB`\nDisk `{lim.get('disk')} MB`\nCPU `{lim.get('cpu')}%`")
        e.add_field(name="Created", value=f"<t:{int(row['created_at'].timestamp())}:R>")
        e.add_field(name="Panel", value=f"[Open]({server_url(self.bot.cfg, row['identifier'])})")
        await send_embed(ctx, e)


async def setup(bot):
    await bot.add_cog(ServerControl(bot))
