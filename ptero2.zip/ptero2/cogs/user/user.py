import discord
from discord.ext import commands

from core.embeds import e_done, e_err, e_info, e_prog, edit_embed, send_embed
from core.linkflow import start_link
from core.passflow import start_reset
from core.ptero import PteroError
from core.service import claim, server_url
from core.views import ConfirmView


class User(commands.Cog):
    category = "user"

    def __init__(self, bot):
        self.bot = bot

    @commands.command(brief="Create your panel account (asks in DMs)")
    async def link(self, ctx):
        await start_link(ctx, ctx.author, admin=False)

    @commands.command(brief="Reset your panel password (asks in DMs)")
    async def resetpassword(self, ctx):
        await start_reset(ctx)

    @commands.command(brief="Claim a free server", usage="<js|py|mc>")
    async def free(self, ctx, kind: str):
        await claim(ctx, "free", kind)

    @commands.command(brief="Show your linked panel account")
    async def panel(self, ctx):
        a = await self.bot.db.get_account(ctx.author.id)
        if not a:
            return await send_embed(ctx, e_err("Not linked", f"Use `{ctx.prefix}link` first."), delete_after=10)
        await send_embed(ctx, e_info("Your panel account",
                         f"**Panel:** {self.bot.cfg.ptero_url}\n**Username:** `{a['username']}`\n**Email:** `{a['email']}`"))

    @commands.command(aliases=["servers"], brief="List your servers")
    async def myservers(self, ctx):
        rows = await self.bot.db.user_servers(ctx.author.id)
        if not rows:
            return await send_embed(ctx, e_info("No servers", "You don't have any servers yet."), delete_after=15)
        lines = [f"**{r['name']}** • ID `{r['ptero_server_id']}` • {r['kind'].upper()} • {r['tier'].title()} • "
                 f"[open]({server_url(self.bot.cfg, r['identifier'])})" for r in rows]
        await send_embed(ctx, e_info(f"Your servers ({len(rows)})", "\n".join(lines)[:4000]))

    @commands.command(brief="Delete one of your servers", usage="<server_id>")
    async def deleteserver(self, ctx, server_id: int):
        row = await self.bot.db.get_server(server_id)
        if not row or row["discord_id"] != ctx.author.id:
            return await send_embed(ctx, e_err("Not found", "That server isn't yours."), delete_after=10)
        view = ConfirmView(ctx.author.id)
        msg = await send_embed(ctx, e_prog("Delete server?", f"**{row['name']}** will be permanently deleted."), view=view)
        await view.wait()
        if not view.value:
            return await edit_embed(msg, e_info("Cancelled"), view=None)
        try:
            await self.bot.ptero.delete_server(server_id)
        except PteroError as e:
            if e.status != 404:
                return await edit_embed(msg, e_err("Panel error", e.message[:300]), view=None)
        await self.bot.db.mark_deleted(server_id)
        await edit_embed(msg, e_done("Server deleted", row["name"]), view=None)


async def setup(bot):
    await bot.add_cog(User(bot))
