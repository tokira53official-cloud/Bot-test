from discord.ext import commands

from core.service import claim


class VIP(commands.Cog):
    category = "vip"

    def __init__(self, bot):
        self.bot = bot

    @commands.command(brief="Create a VIP server (VIP role)", usage="<js|py|mc>")
    async def vip(self, ctx, kind: str):
        await claim(ctx, "vip", kind)


async def setup(bot):
    await bot.add_cog(VIP(bot))
