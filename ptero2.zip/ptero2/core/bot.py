import asyncio
import hashlib
import logging
import time

import aiohttp
import discord
from discord.ext import commands

from . import embeds
from .checks import NotAdmin
from .config import BASE_DIR, Settings
from .db import Database
from .embeds import e_err, send_embed
from .ptero import Ptero

log = logging.getLogger("bot")


class PteroBot(commands.AutoShardedBot):
    def __init__(self, cfg: Settings):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True
        super().__init__(command_prefix=cfg.prefix, intents=intents, help_command=None,
                         shard_count=cfg.shard_count or None, case_insensitive=True)
        self.cfg = cfg
        self.db = Database(cfg.database_url)
        self.ptero = Ptero(cfg.ptero_url, cfg.ptero_key, cfg.ptero_client_key)
        self.admin_ids: set = set()
        self.blacklist: set = set()
        self.blacklisted_guilds: set = set()
        self.start_time = None
        self.maintenance = False
        self._ready_once = False
        self.add_check(self.global_check)
        self.after_invoke(self._after)

    # ---------- lifecycle ----------
    async def setup_hook(self):
        embeds.load_banner(BASE_DIR / "assets" / "banner.png")
        await self.db.connect()
        await self.ptero.start()
        self.admin_ids = await self.db.load_ids("bot_admins", "user_id")
        self.blacklist = await self.db.load_ids("blacklisted_users", "user_id")
        self.blacklisted_guilds = await self.db.load_ids("blacklisted_servers", "guild_id")
        self.maintenance = (await self.db.kv_get("maintenance")) == "1"
        for folder in sorted((BASE_DIR / "cogs").iterdir()):
            if not folder.is_dir() or folder.name.startswith("_"):
                continue
            for f in sorted(folder.glob("*.py")):
                if f.name.startswith("_"):
                    continue
                ext = f"cogs.{folder.name}.{f.stem}"
                try:
                    await self.load_extension(ext)
                    log.info("loaded %s", ext)
                except Exception:
                    log.exception("failed to load %s", ext)

    async def close(self):
        await self.ptero.close()
        await self.db.close()
        await super().close()

    async def on_ready(self):
        if self.start_time is None:
            self.start_time = time.time()
        if self._ready_once:
            return
        self._ready_once = True
        await self.apply_profile()
        stale = await self.db.cleanup_stale()
        if stale:
            log.warning("marked %s stale 'creating' rows as failed", stale)
        log.info("Ready as %s (%s guilds)", self.user, len(self.guilds))

    async def apply_profile(self):
        c = self.cfg
        try:
            if c.bot_name and self.user.name != c.bot_name:
                await self.user.edit(username=c.bot_name)
        except discord.HTTPException as e:
            log.warning("name change failed: %s", e)
        if c.avatar_url:
            h = hashlib.sha256(c.avatar_url.encode()).hexdigest()
            if await self.db.kv_get("avatar_hash") != h:
                try:
                    async with aiohttp.ClientSession() as s, s.get(c.avatar_url) as r:
                        data = await r.read()
                    await self.user.edit(avatar=data)
                    await self.db.kv_set("avatar_hash", h)
                except Exception as e:
                    log.warning("avatar change failed: %s", e)
        types = {"playing": discord.ActivityType.playing, "watching": discord.ActivityType.watching,
                 "listening": discord.ActivityType.listening, "competing": discord.ActivityType.competing}
        statuses = {"online": discord.Status.online, "idle": discord.Status.idle, "dnd": discord.Status.dnd}
        act = discord.Activity(type=types.get(c.status_type, discord.ActivityType.playing),
                               name=c.status_text) if c.status_text else None
        await self.change_presence(activity=act, status=statuses.get(c.presence, discord.Status.online))

    # ---------- events ----------
    async def on_member_join(self, member: discord.Member):
        if member.bot or member.guild.id != self.cfg.guild_id:
            return
        role = member.guild.get_role(self.cfg.tiers["free"].role_id)
        if role:
            try:
                await member.add_roles(role, reason="Free role on join")
            except discord.HTTPException:
                pass

    async def on_guild_join(self, guild: discord.Guild):
        if guild.id in self.blacklisted_guilds:
            await guild.leave()

    # ---------- global check: owner bypass → blacklist → DM block → channel ----------
    async def global_check(self, ctx: commands.Context) -> bool:
        cfg = self.cfg
        if ctx.author.id in cfg.owner_ids:
            return True
        if self.maintenance:
            await send_embed(ctx, e_err("Maintenance", "The bot is under maintenance. Try again later."), delete_after=8)
            return False
        if ctx.author.id in self.blacklist:
            await send_embed(ctx, e_err("Blacklisted", "You are not allowed to use this bot."), delete_after=8)
            return False
        if ctx.guild is None:
            where = f"<#{cfg.command_channel_id}>" if cfg.command_channel_id else "the server"
            await send_embed(ctx, e_err("Not in DMs", f"Please use commands in {where}."))
            return False
        if ctx.guild.id in self.blacklisted_guilds:
            await ctx.guild.leave()
            return False
        if cfg.guild_id and ctx.guild.id != cfg.guild_id:
            return False
        if cfg.command_channel_id and ctx.channel.id != cfg.command_channel_id:
            try:
                await ctx.message.delete()
            except discord.HTTPException:
                pass
            await send_embed(ctx, e_err("Wrong channel", f"Use commands in <#{cfg.command_channel_id}>."), delete_after=6)
            return False
        return True

    async def _after(self, ctx: commands.Context):
        try:
            await self.db.bump_stat(ctx.author.id)
        except Exception:
            log.exception("stat update failed")

    async def on_command_error(self, ctx: commands.Context, error: Exception):
        error = getattr(error, "original", error)
        if isinstance(error, NotAdmin):
            return await send_embed(ctx, e_err("Admins only", "You don't have permission for this command."), delete_after=8)
        if isinstance(error, (commands.CommandNotFound, commands.CheckFailure)):
            return
        if isinstance(error, (commands.MissingRequiredArgument, commands.BadArgument, commands.BadUnionArgument)):
            usage = f"{ctx.prefix}{ctx.command.qualified_name} {ctx.command.signature}".strip()
            return await send_embed(ctx, e_err("Invalid usage", f"`{usage}`"), delete_after=10)
        if isinstance(error, commands.CommandOnCooldown):
            return await send_embed(ctx, e_err("Slow down", f"Try again in {error.retry_after:.0f}s."), delete_after=5)
        log.exception("command error in %s", ctx.command, exc_info=error)
        await send_embed(ctx, e_err("Something went wrong", "The error was logged. Please try again."), delete_after=10)
