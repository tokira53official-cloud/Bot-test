from discord.ext import commands


class NotAdmin(commands.CheckFailure):
    pass


def owner_only():
    async def predicate(ctx):
        return ctx.author.id in ctx.bot.cfg.owner_ids  # silent fail for non-owners
    return commands.check(predicate)


def admin_only():
    async def predicate(ctx):
        if ctx.author.id in ctx.bot.cfg.owner_ids or ctx.author.id in ctx.bot.admin_ids:
            return True
        raise NotAdmin("Admins only")
    return commands.check(predicate)
