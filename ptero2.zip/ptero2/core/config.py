"""All configuration comes from .env — nothing is hardcoded."""
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")


def _s(name: str, default: str = "") -> str:
    return os.getenv(name, default).strip()


def _i(name: str, default: int = 0) -> int:
    try:
        return int(_s(name, str(default)) or default)
    except ValueError:
        return default


def _b(name: str, default: bool = False) -> bool:
    return _s(name, str(default)).lower() in ("1", "true", "yes", "on")


def _ids(name: str) -> List[int]:
    return [int(p) for p in _s(name).replace(" ", "").split(",") if p.isdigit()]


@dataclass(frozen=True)
class Tier:
    key: str
    label: str
    enabled: bool
    role_id: int
    ram: int
    disk: int
    cpu: int
    databases: int
    backups: int
    allocations: int
    max_per_user: int
    global_limit: int


@dataclass(frozen=True)
class Kind:
    key: str
    label: str
    nest_id: int
    egg_id: int


_DEFAULTS = {
    "free": dict(ram=512, disk=1024, cpu=50, databases=0, backups=0, allocations=1, max_per_user=1, global_limit=20),
    "premium": dict(ram=2048, disk=5120, cpu=100, databases=1, backups=1, allocations=2, max_per_user=3, global_limit=0),
    "vip": dict(ram=4096, disk=10240, cpu=200, databases=2, backups=2, allocations=3, max_per_user=5, global_limit=0),
}


def _tier(key: str, label: str) -> Tier:
    p, d = key.upper() + "_", _DEFAULTS[key]
    return Tier(
        key, label, _b(p + "ENABLED", False), _i(p + "ROLE_ID"),
        _i(p + "RAM", d["ram"]), _i(p + "DISK", d["disk"]), _i(p + "CPU", d["cpu"]),
        _i(p + "DATABASES", d["databases"]), _i(p + "BACKUPS", d["backups"]),
        _i(p + "ALLOCATIONS", d["allocations"]), _i(p + "MAX_PER_USER", d["max_per_user"]),
        _i(p + "GLOBAL_LIMIT", d["global_limit"]),
    )


class Settings:
    def __init__(self) -> None:
        self.token = _s("DISCORD_TOKEN")
        self.prefix = _s("PREFIX", "!") or "!"
        self.owner_ids = _ids("OWNER_IDS")
        self.guild_id = _i("GUILD_ID")
        self.command_channel_id = _i("COMMAND_CHANNEL_ID")
        self.whitelist_guilds = _ids("WHITELIST_GUILDS")
        self.shard_count = _i("SHARD_COUNT")

        self.bot_name = _s("BOT_NAME", "PteroManager")
        self.tagline = _s("BOT_TAGLINE", "Pterodactyl made easy")
        self.avatar_url = _s("BOT_AVATAR_URL")
        self.status_text = _s("BOT_STATUS_TEXT")
        self.status_type = _s("BOT_STATUS_TYPE", "watching").lower()
        self.presence = _s("BOT_PRESENCE", "online").lower()
        self.footer = f"</> {self.bot_name} • {self.tagline}"

        self.database_url = _s("DATABASE_URL")
        self.ptero_url = _s("PTERO_URL").rstrip("/")
        self.ptero_key = _s("PTERO_API_KEY")
        self.ptero_client_key = _s("PTERO_CLIENT_API_KEY")
        self.locations = _ids("PTERO_LOCATION_IDS")

        self.kinds: Dict[str, Kind] = {
            "js": Kind("js", "Node.js", _i("JS_NEST_ID"), _i("JS_EGG_ID")),
            "py": Kind("py", "Python", _i("PY_NEST_ID"), _i("PY_EGG_ID")),
            "mc": Kind("mc", "Minecraft", _i("MC_NEST_ID"), _i("MC_EGG_ID")),
        }
        self.tiers: Dict[str, Tier] = {
            "free": _tier("free", "Free"),
            "premium": _tier("premium", "Premium"),
            "vip": _tier("vip", "VIP"),
        }

    def validate(self) -> List[str]:
        bad = []
        for name, val in (("DISCORD_TOKEN", self.token), ("DATABASE_URL", self.database_url),
                          ("PTERO_URL", self.ptero_url), ("PTERO_API_KEY", self.ptero_key)):
            if not val:
                bad.append(f"{name} is missing")
        if not self.owner_ids:
            bad.append("OWNER_IDS needs at least one user id")
        return bad


cfg = Settings()
