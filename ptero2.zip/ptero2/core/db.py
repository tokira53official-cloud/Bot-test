"""PostgreSQL layer (asyncpg). Every write is awaited; failures after a panel action
are also appended to data_recovery.jsonl so nothing is ever silently lost."""
import json
import logging
import time
from pathlib import Path
from typing import Optional, Set

import asyncpg

log = logging.getLogger("db")
JOURNAL = Path(__file__).resolve().parent.parent / "data_recovery.jsonl"

SCHEMA = """
CREATE TABLE IF NOT EXISTS accounts(
    discord_id BIGINT PRIMARY KEY, ptero_user_id INT NOT NULL, email TEXT NOT NULL,
    username TEXT NOT NULL, panel_admin BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS servers(
    id BIGSERIAL PRIMARY KEY, discord_id BIGINT NOT NULL, ptero_server_id INT UNIQUE,
    identifier TEXT, name TEXT NOT NULL, tier TEXT NOT NULL, kind TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'creating', created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE INDEX IF NOT EXISTS servers_user_idx ON servers(discord_id);
ALTER TABLE servers ADD COLUMN IF NOT EXISTS suspended BOOLEAN NOT NULL DEFAULT FALSE;
CREATE TABLE IF NOT EXISTS stats(
    discord_id BIGINT PRIMARY KEY, commands_used BIGINT NOT NULL DEFAULT 0,
    servers_created BIGINT NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS bot_admins(
    user_id BIGINT PRIMARY KEY, added_by BIGINT, added_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS blacklisted_users(
    user_id BIGINT PRIMARY KEY, reason TEXT, added_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS blacklisted_servers(
    guild_id BIGINT PRIMARY KEY, added_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS kv(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS warnings(
    id BIGSERIAL PRIMARY KEY, user_id BIGINT NOT NULL, mod_id BIGINT NOT NULL,
    reason TEXT NOT NULL, at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS audit(
    id BIGSERIAL PRIMARY KEY, actor BIGINT, action TEXT, detail TEXT,
    at TIMESTAMPTZ NOT NULL DEFAULT now());
"""


def journal(kind: str, payload: dict) -> None:
    try:
        with open(JOURNAL, "a", encoding="utf-8") as f:
            f.write(json.dumps({"t": time.time(), "kind": kind, "data": payload}, default=str) + "\n")
    except Exception:
        log.exception("could not write recovery journal")


class Database:
    def __init__(self, dsn: str):
        self.dsn = dsn
        self.pool: Optional[asyncpg.Pool] = None

    async def connect(self) -> None:
        self.pool = await asyncpg.create_pool(self.dsn, min_size=1, max_size=5, command_timeout=30)
        async with self.pool.acquire() as c:
            await c.execute(SCHEMA)

    async def close(self) -> None:
        if self.pool:
            await self.pool.close()

    async def load_ids(self, table: str, col: str) -> Set[int]:
        rows = await self.pool.fetch(f"SELECT {col} FROM {table}")
        return {r[0] for r in rows}

    # ---------- admins ----------
    async def add_admin(self, uid: int, by: int) -> None:
        await self.pool.execute("INSERT INTO bot_admins(user_id, added_by) VALUES($1,$2) ON CONFLICT DO NOTHING", uid, by)

    async def remove_admin(self, uid: int) -> None:
        await self.pool.execute("DELETE FROM bot_admins WHERE user_id=$1", uid)

    # ---------- blacklist ----------
    async def blacklist_user(self, uid: int, reason: str) -> None:
        await self.pool.execute(
            "INSERT INTO blacklisted_users(user_id, reason) VALUES($1,$2) "
            "ON CONFLICT (user_id) DO UPDATE SET reason=EXCLUDED.reason", uid, reason)

    async def unblacklist_user(self, uid: int) -> None:
        await self.pool.execute("DELETE FROM blacklisted_users WHERE user_id=$1", uid)

    async def blacklisted_users(self):
        return await self.pool.fetch("SELECT user_id, reason, added_at FROM blacklisted_users ORDER BY added_at")

    async def blacklist_server(self, gid: int) -> None:
        await self.pool.execute("INSERT INTO blacklisted_servers(guild_id) VALUES($1) ON CONFLICT DO NOTHING", gid)

    async def unblacklist_server(self, gid: int) -> None:
        await self.pool.execute("DELETE FROM blacklisted_servers WHERE guild_id=$1", gid)

    async def blacklisted_servers(self):
        return await self.pool.fetch("SELECT guild_id, added_at FROM blacklisted_servers ORDER BY added_at")

    # ---------- accounts ----------
    async def get_account(self, discord_id: int):
        return await self.pool.fetchrow("SELECT * FROM accounts WHERE discord_id=$1", discord_id)

    async def save_account(self, discord_id, ptero_user_id, email, username, panel_admin) -> None:
        try:
            await self.pool.execute(
                "INSERT INTO accounts(discord_id, ptero_user_id, email, username, panel_admin) "
                "VALUES($1,$2,$3,$4,$5) ON CONFLICT (discord_id) DO UPDATE SET "
                "ptero_user_id=EXCLUDED.ptero_user_id, email=EXCLUDED.email, "
                "username=EXCLUDED.username, panel_admin=EXCLUDED.panel_admin",
                discord_id, ptero_user_id, email, username, panel_admin)
        except Exception:
            journal("account", dict(discord_id=discord_id, ptero_user_id=ptero_user_id,
                                    email=email, username=username, panel_admin=panel_admin))
            raise

    # ---------- servers ----------
    async def reserve_server(self, discord_id, tier, kind, name, max_per_user, global_limit, bypass=False):
        """Atomically checks limits and reserves a slot BEFORE the panel is touched."""
        async with self.pool.acquire() as c:
            async with c.transaction():
                await c.execute("SELECT pg_advisory_xact_lock(4815162342)")
                if not bypass:
                    if global_limit > 0:
                        g = await c.fetchval(
                            "SELECT count(*) FROM servers WHERE tier=$1 AND status IN ('creating','active')", tier)
                        if g >= global_limit:
                            return ("global_limit", g)
                    if max_per_user > 0:
                        u = await c.fetchval(
                            "SELECT count(*) FROM servers WHERE tier=$1 AND discord_id=$2 "
                            "AND status IN ('creating','active')", tier, discord_id)
                        if u >= max_per_user:
                            return ("user_limit", u)
                rid = await c.fetchval(
                    "INSERT INTO servers(discord_id, name, tier, kind, status) "
                    "VALUES($1,$2,$3,$4,'creating') RETURNING id", discord_id, name, tier, kind)
                return ("ok", rid)

    async def finalize_server(self, rid: int, ptero_id: int, identifier: str) -> None:
        try:
            await self.pool.execute(
                "UPDATE servers SET ptero_server_id=$2, identifier=$3, status='active' WHERE id=$1",
                rid, ptero_id, identifier)
        except Exception:
            journal("server", dict(row_id=rid, ptero_server_id=ptero_id, identifier=identifier))
            raise

    async def fail_server(self, rid: int) -> None:
        await self.pool.execute("UPDATE servers SET status='failed' WHERE id=$1", rid)

    async def cleanup_stale(self) -> int:
        rows = await self.pool.fetch(
            "UPDATE servers SET status='failed' WHERE status='creating' "
            "AND created_at < now() - interval '15 minutes' RETURNING id")
        return len(rows)

    async def mark_deleted(self, ptero_id: int) -> None:
        await self.pool.execute("UPDATE servers SET status='deleted' WHERE ptero_server_id=$1", ptero_id)

    async def get_server(self, ptero_id: int):
        return await self.pool.fetchrow("SELECT * FROM servers WHERE ptero_server_id=$1 AND status='active'", ptero_id)

    async def user_servers(self, discord_id: int):
        return await self.pool.fetch(
            "SELECT * FROM servers WHERE discord_id=$1 AND status='active' ORDER BY created_at", discord_id)

    async def counts(self) -> dict:
        p = self.pool
        return {
            "accounts": await p.fetchval("SELECT count(*) FROM accounts"),
            "servers": await p.fetchval("SELECT count(*) FROM servers WHERE status='active'"),
            "free": await p.fetchval("SELECT count(*) FROM servers WHERE status='active' AND tier='free'"),
            "premium": await p.fetchval("SELECT count(*) FROM servers WHERE status='active' AND tier='premium'"),
            "vip": await p.fetchval("SELECT count(*) FROM servers WHERE status='active' AND tier='vip'"),
        }

    # ---------- misc ----------
    async def bump_stat(self, uid: int, servers: int = 0) -> None:
        await self.pool.execute(
            "INSERT INTO stats(discord_id, commands_used, servers_created) VALUES($1, $2, $3) "
            "ON CONFLICT (discord_id) DO UPDATE SET commands_used=stats.commands_used+$2, "
            "servers_created=stats.servers_created+$3", uid, 0 if servers else 1, servers)

    async def kv_get(self, key: str) -> Optional[str]:
        return await self.pool.fetchval("SELECT value FROM kv WHERE key=$1", key)

    async def kv_set(self, key: str, value: str) -> None:
        await self.pool.execute(
            "INSERT INTO kv(key,value) VALUES($1,$2) ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value", key, value)

    async def audit(self, actor: int, action: str, detail: str = "") -> None:
        try:
            await self.pool.execute("INSERT INTO audit(actor, action, detail) VALUES($1,$2,$3)", actor, action, detail)
        except Exception:
            log.exception("audit failed")

    # ---------- v2 additions ----------
    async def account_by_ptero_user(self, ptero_user_id):
        return await self.pool.fetchrow("SELECT * FROM accounts WHERE ptero_user_id=$1", ptero_user_id)

    async def accounts_by_ptero_users(self, ids) -> dict:
        rows = await self.pool.fetch(
            "SELECT ptero_user_id, discord_id FROM accounts WHERE ptero_user_id = ANY($1::int[])", list(set(ids)))
        return {r["ptero_user_id"]: r["discord_id"] for r in rows}

    async def all_account_ids(self):
        return [r[0] for r in await self.pool.fetch("SELECT discord_id FROM accounts")]

    async def tracked_servers(self):
        return await self.pool.fetch(
            "SELECT ptero_server_id, discord_id, name, suspended FROM servers "
            "WHERE status='active' AND ptero_server_id IS NOT NULL")

    async def set_suspended(self, ptero_id: int, value: bool) -> None:
        await self.pool.execute("UPDATE servers SET suspended=$2 WHERE ptero_server_id=$1", ptero_id, value)

    # ---------- v3 additions ----------
    async def add_warning(self, uid: int, mod: int, reason: str) -> None:
        await self.pool.execute("INSERT INTO warnings(user_id, mod_id, reason) VALUES($1,$2,$3)", uid, mod, reason)

    async def get_warnings(self, uid: int):
        return await self.pool.fetch("SELECT * FROM warnings WHERE user_id=$1 ORDER BY at", uid)

    async def clear_warnings(self, uid: int) -> int:
        rows = await self.pool.fetch("DELETE FROM warnings WHERE user_id=$1 RETURNING id", uid)
        return len(rows)

    async def rename_server(self, ptero_id: int, name: str) -> None:
        await self.pool.execute("UPDATE servers SET name=$2 WHERE ptero_server_id=$1", ptero_id, name)

    async def set_server_tier(self, ptero_id: int, tier: str) -> None:
        await self.pool.execute("UPDATE servers SET tier=$2 WHERE ptero_server_id=$1", ptero_id, tier)

    async def set_server_owner(self, ptero_id: int, discord_id: int) -> None:
        await self.pool.execute("UPDATE servers SET discord_id=$2 WHERE ptero_server_id=$1", ptero_id, discord_id)

    async def update_account(self, discord_id: int, *, email=None, username=None) -> None:
        await self.pool.execute(
            "UPDATE accounts SET email=COALESCE($2,email), username=COALESCE($3,username) WHERE discord_id=$1",
            discord_id, email, username)

    async def get_stats(self, uid: int):
        return await self.pool.fetchrow("SELECT * FROM stats WHERE discord_id=$1", uid)

    async def leaderboard(self, n: int = 10):
        return await self.pool.fetch(
            "SELECT discord_id, commands_used, servers_created FROM stats "
            "ORDER BY servers_created DESC, commands_used DESC LIMIT $1", n)

    async def count_user_tier(self, uid: int, tier: str) -> int:
        return await self.pool.fetchval(
            "SELECT count(*) FROM servers WHERE discord_id=$1 AND tier=$2 AND status IN ('creating','active')", uid, tier)

    async def audit_recent(self, n: int = 15):
        return await self.pool.fetch("SELECT actor, action, detail, at FROM audit ORDER BY id DESC LIMIT $1", n)

    async def export_all(self) -> dict:
        out = {}
        for t in ("accounts", "servers", "stats", "bot_admins", "blacklisted_users",
                  "blacklisted_servers", "warnings", "audit"):
            out[t] = [dict(r) for r in await self.pool.fetch(f"SELECT * FROM {t}")]
        return out
