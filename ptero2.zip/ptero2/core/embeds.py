"""Embed colours, emoji system and the send/edit helpers (banner on every embed)."""
import io
from pathlib import Path
from typing import Dict, Optional

import discord

from .config import cfg

COL_GRAY = 0x2B2B33
COL_BLACK = 0x2B2B33
COL_YELLOW = 0xFAA61A
COL_GREEN = 0x57F287
COL_RED = 0xED4245

FOOTER = cfg.footer
BANNER_FILENAME = "banner.png"
BANNER_BYTES: Optional[bytes] = None
EMOJI_MAP: Dict[str, str] = {}


def ge(name: str, fallback: str = "") -> str:
    return EMOJI_MAP.get(name, fallback)


def load_banner(path: Path) -> None:
    global BANNER_BYTES
    try:
        BANNER_BYTES = Path(path).read_bytes()
    except OSError:
        BANNER_BYTES = None


def finish(e: discord.Embed) -> discord.Embed:
    e.set_footer(text=FOOTER)
    if BANNER_BYTES and not e.image.url:
        e.set_image(url=f"attachment://{BANNER_FILENAME}")
    return e


def make_embed(title: str, desc: str = "", color: int = COL_GRAY) -> discord.Embed:
    return finish(discord.Embed(title=title, description=desc or None, color=color))


def e_main(title, desc=""):  return make_embed(title, desc, COL_BLACK)
def e_info(title, desc=""):  return make_embed(f"{ge('info', 'ℹ️')} {title}", desc, COL_GRAY)
def e_prog(title, desc=""):  return make_embed(f"{ge('loading', '⏳')} {title}", desc, COL_YELLOW)
def e_done(title, desc=""):  return make_embed(f"{ge('check', '✅')} {title}", desc, COL_GREEN)
def e_err(title, desc=""):   return make_embed(f"{ge('cross', '❌')} {title}", desc, COL_RED)


async def send_embed(target, embed: discord.Embed, **kwargs):
    """target: Context, Messageable/User/Member, or Interaction."""
    finish(embed)
    if BANNER_BYTES and embed.image.url == f"attachment://{BANNER_FILENAME}":
        kwargs["file"] = discord.File(io.BytesIO(BANNER_BYTES), filename=BANNER_FILENAME)
    kwargs["embed"] = embed
    if isinstance(target, discord.Interaction):
        if target.response.is_done():
            return await target.followup.send(wait=True, **kwargs)
        await target.response.send_message(**kwargs)
        return await target.original_response()
    return await target.send(**kwargs)


async def edit_embed(msg, embed: discord.Embed, **kwargs):
    finish(embed)
    return await msg.edit(embed=embed, **kwargs)


async def owner_reply(ctx, embed: discord.Embed):
    """Owner results are DMed privately; fall back to the channel if DMs are closed."""
    try:
        await send_embed(ctx.author, embed)
    except discord.Forbidden:
        await send_embed(ctx, embed)
