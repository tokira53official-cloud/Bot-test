"""DM-based account linking: button -> modal -> panel account."""
import logging
import re

import discord
from discord import ui

from .embeds import e_done, e_err, e_info, send_embed
from .ptero import PteroError
from .service import give_role

log = logging.getLogger("link")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def clean_username(raw: str, fallback: str, uid: int) -> str:
    for candidate in (raw or "", fallback or ""):
        u = re.sub(r"[^A-Za-z0-9_.-]", "", candidate.strip()).strip("_.-")
        if u:
            return u[:30]
    return f"user{uid % 100000}"


class LinkForm(ui.Modal, title="Link Panel Account"):
    first = ui.TextInput(label="First name", max_length=40)
    last = ui.TextInput(label="Last name", max_length=40)
    username = ui.TextInput(label="Panel username", required=False, max_length=30,
                            placeholder="Blank = your Discord username")
    email = ui.TextInput(label="Email", max_length=120, placeholder="you@example.com")
    password = ui.TextInput(label="Password (min 8 characters)", min_length=8, max_length=64)

    def __init__(self, bot, target_id: int, target_name: str, admin: bool):
        super().__init__()
        self.bot, self.target_id, self.target_name, self.admin = bot, target_id, target_name, admin

    async def on_submit(self, inter: discord.Interaction):
        # NEVER edit_message() on a modal submit — defer, then followup.
        await inter.response.defer(ephemeral=True, thinking=True)
        bot, cfg = self.bot, self.bot.cfg
        email = str(self.email).strip().lower()
        if not EMAIL_RE.match(email):
            return await send_embed(inter, e_err("Invalid email", "Press the button and try again."), ephemeral=True)
        if await bot.db.get_account(self.target_id):
            return await send_embed(inter, e_err("Already linked", "That Discord user already has an account."), ephemeral=True)
        username = clean_username(str(self.username), self.target_name, self.target_id)
        try:
            u = await bot.ptero.create_user(email=email, username=username, first=str(self.first).strip(),
                                            last=str(self.last).strip(), password=str(self.password),
                                            admin=self.admin)
        except PteroError as e:
            return await send_embed(inter, e_err("Panel refused the account", e.message[:400]), ephemeral=True)
        try:
            await bot.db.save_account(self.target_id, u["id"], email, u["username"], self.admin)
        except Exception:
            log.exception("save_account failed")
            return await send_embed(inter, e_err(
                "Saved to recovery journal",
                "Your panel account exists but the database write failed. An owner can restore it from `data_recovery.jsonl`."),
                ephemeral=True)
        await bot.db.audit(inter.user.id, "link_admin" if self.admin else "link", f"{self.target_id}:{u['id']}")
        if not self.admin:
            await give_role(bot, self.target_id, cfg.tiers["free"].role_id, "Linked panel account")
        emb = e_done("Account created" if not self.admin else "Admin account created",
                     f"**Panel:** {cfg.ptero_url}\n**Username:** `{u['username']}`\n**Email:** `{email}`\n\n"
                     "Your password is **not stored** by the bot. You can now use the server commands.")
        await send_embed(inter, emb, ephemeral=True)


class LinkStartView(ui.View):
    def __init__(self, bot, uid: int, target_id: int, target_name: str, admin: bool):
        super().__init__(timeout=300)
        self.bot, self.uid, self.target_id, self.target_name, self.admin = bot, uid, target_id, target_name, admin

    @ui.button(label="Open form", style=discord.ButtonStyle.primary, row=0)
    async def open_form(self, inter: discord.Interaction, button: ui.Button):
        if inter.user.id != self.uid:
            return
        await inter.response.send_modal(LinkForm(self.bot, self.target_id, self.target_name, self.admin))


async def start_link(ctx, member, admin: bool = False) -> None:
    bot = ctx.bot
    if await bot.db.get_account(member.id):
        return await send_embed(ctx, e_err("Already linked", f"{member.mention} already has a panel account."), delete_after=10)
    view = LinkStartView(bot, ctx.author.id, member.id, member.name, admin)
    emb = e_info("Link your panel account",
                 "Press **Open form** and fill in your first name, last name, username, email and password.\n"
                 "Your password is sent only to the panel and is never stored by the bot.")
    try:
        await send_embed(ctx.author, emb, view=view)
    except discord.Forbidden:
        return await send_embed(ctx, e_err("DMs closed", "Enable DMs from server members and try again."), delete_after=10)
    if ctx.guild:
        await send_embed(ctx, e_done("Check your DMs", "I sent you the account form."), delete_after=10)
