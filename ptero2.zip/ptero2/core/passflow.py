"""!resetpassword — DM button -> modal -> panel password reset."""
import discord
from discord import ui

from .embeds import e_done, e_err, e_info, send_embed
from .ptero import PteroError


class PassForm(ui.Modal, title="Reset Panel Password"):
    new = ui.TextInput(label="New password (min 8 characters)", min_length=8, max_length=64)
    confirm = ui.TextInput(label="Confirm new password", min_length=8, max_length=64)

    def __init__(self, bot, ptero_user_id: int):
        super().__init__()
        self.bot, self.ptero_user_id = bot, ptero_user_id

    async def on_submit(self, inter: discord.Interaction):
        await inter.response.defer(ephemeral=True, thinking=True)  # never edit_message on modal submit
        if str(self.new) != str(self.confirm):
            return await send_embed(inter, e_err("Passwords don't match", "Press the button and try again."), ephemeral=True)
        try:
            await self.bot.ptero.reset_password(self.ptero_user_id, str(self.new))
        except PteroError as e:
            return await send_embed(inter, e_err("Panel refused", e.message[:400]), ephemeral=True)
        await self.bot.db.audit(inter.user.id, "reset_password", str(self.ptero_user_id))
        await send_embed(inter, e_done("Password updated", "You can log in with the new password now."), ephemeral=True)


class PassStartView(ui.View):
    def __init__(self, bot, uid: int, ptero_user_id: int):
        super().__init__(timeout=300)
        self.bot, self.uid, self.ptero_user_id = bot, uid, ptero_user_id

    @ui.button(label="Set new password", style=discord.ButtonStyle.primary, row=0)
    async def open_form(self, inter: discord.Interaction, button: ui.Button):
        if inter.user.id != self.uid:
            return
        await inter.response.send_modal(PassForm(self.bot, self.ptero_user_id))


async def start_reset(ctx) -> None:
    acct = await ctx.bot.db.get_account(ctx.author.id)
    if not acct:
        return await send_embed(ctx, e_err("Not linked", f"Use `{ctx.prefix}link` first."), delete_after=10)
    try:
        await send_embed(ctx.author, e_info("Reset your panel password", "Press the button below."),
                         view=PassStartView(ctx.bot, ctx.author.id, acct["ptero_user_id"]))
    except discord.Forbidden:
        return await send_embed(ctx, e_err("DMs closed", "Enable DMs from server members and try again."), delete_after=10)
    if ctx.guild:
        await send_embed(ctx, e_done("Check your DMs", "I sent you the password form."), delete_after=10)
