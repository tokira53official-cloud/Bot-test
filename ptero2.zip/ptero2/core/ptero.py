"""Async Pterodactyl *Application API* client."""
import asyncio
import logging
import time
from typing import Any, Dict, List, Optional

import aiohttp

log = logging.getLogger("ptero")


class PteroError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status
        self.message = message


class Ptero:
    def __init__(self, url: str, key: str, client_key: str = ""):
        self.url = url.rstrip("/")
        self.key = key
        self.client_key = client_key
        self.session: Optional[aiohttp.ClientSession] = None
        self._eggs: Dict[tuple, dict] = {}

    async def start(self) -> None:
        self.session = aiohttp.ClientSession(
            headers={"Authorization": f"Bearer {self.key}",
                     "Accept": "Application/vnd.pterodactyl.v1+json",
                     "Content-Type": "application/json"},
            timeout=aiohttp.ClientTimeout(total=45),
        )

    async def close(self) -> None:
        if self.session:
            await self.session.close()

    async def _req(self, method: str, path: str, *, json: Any = None, params: Any = None, client: bool = False) -> dict:
        headers = None
        if client:
            if not self.client_key:
                raise PteroError(0, "PTERO_CLIENT_API_KEY is not set in .env (needed for power controls).")
            headers = {"Authorization": f"Bearer {self.client_key}"}
        url = f"{self.url}/api/{'client' if client else 'application'}{path}"
        # POSTs are never blindly retried (avoids duplicate servers/users)
        retry_codes = (429,) if method == "POST" else (429, 502, 503, 504)
        for attempt in range(4):
            try:
                async with self.session.request(method, url, json=json, params=params, headers=headers) as r:
                    if r.status in retry_codes and attempt < 3:
                        await asyncio.sleep(1.5 * (attempt + 1))
                        continue
                    if r.status == 204:
                        return {}
                    try:
                        data = await r.json(content_type=None)
                    except Exception:
                        data = {}
                    if r.status >= 400:
                        errs = (data or {}).get("errors") or []
                        msg = "; ".join(e.get("detail") or e.get("code", "") for e in errs) or f"HTTP {r.status}"
                        raise PteroError(r.status, msg)
                    return data or {}
            except (aiohttp.ClientError, asyncio.TimeoutError) as ex:
                if method == "POST" or attempt == 3:
                    raise PteroError(0, f"Panel unreachable ({ex.__class__.__name__}). Check the panel before retrying.")
                await asyncio.sleep(1.5 * (attempt + 1))
        raise PteroError(0, "Request failed")

    # ---------- users ----------
    async def create_user(self, *, email, username, first, last, password, admin=False) -> dict:
        d = await self._req("POST", "/users", json={
            "email": email, "username": username, "first_name": first, "last_name": last,
            "password": password, "root_admin": admin, "language": "en"})
        return d["attributes"]

    # ---------- eggs ----------
    async def get_egg(self, nest: int, egg: int) -> dict:
        key = (nest, egg)
        if key in self._eggs:
            return self._eggs[key]
        d = await self._req("GET", f"/nests/{nest}/eggs/{egg}", params={"include": "variables"})
        a = d["attributes"]
        image = a.get("docker_image") or next(iter((a.get("docker_images") or {}).values()), None)
        variables = a.get("relationships", {}).get("variables", {}).get("data", [])
        env = {v["attributes"]["env_variable"]: v["attributes"].get("default_value") or "" for v in variables}
        info = {"startup": a["startup"], "image": image, "env": env}
        self._eggs[key] = info
        return info

    # ---------- servers ----------
    async def create_server(self, *, name, user_id, nest, egg, ram, disk, cpu,
                            databases, backups, allocations, locations: List[int]) -> dict:
        if not locations:
            raise PteroError(0, "PTERO_LOCATION_IDS is empty in .env")
        e = await self.get_egg(nest, egg)
        payload = {
            "name": name, "user": user_id, "egg": egg,
            "docker_image": e["image"], "startup": e["startup"], "environment": e["env"],
            "limits": {"memory": ram, "swap": 0, "disk": disk, "io": 500, "cpu": cpu},
            "feature_limits": {"databases": databases, "backups": backups, "allocations": allocations},
            "deploy": {"locations": locations, "dedicated_ip": False, "port_range": []},
            "start_on_completion": True,
        }
        d = await self._req("POST", "/servers", json=payload)
        return d["attributes"]

    async def delete_server(self, sid: int, force: bool = False) -> None:
        await self._req("DELETE", f"/servers/{sid}" + ("/force" if force else ""))

    async def suspend(self, sid: int) -> None:
        await self._req("POST", f"/servers/{sid}/suspend")

    async def unsuspend(self, sid: int) -> None:
        await self._req("POST", f"/servers/{sid}/unsuspend")

    async def ping(self):
        t = time.perf_counter()
        d = await self._req("GET", "/nodes", params={"per_page": 1})
        return int((time.perf_counter() - t) * 1000), d.get("meta", {}).get("pagination", {}).get("total", 0)

    # ---------- extras ----------
    async def get_user(self, uid: int) -> dict:
        return (await self._req("GET", f"/users/{uid}"))["attributes"]

    async def reset_password(self, uid: int, password: str) -> None:
        u = await self.get_user(uid)  # PATCH needs the full user payload
        await self._req("PATCH", f"/users/{uid}", json={
            "email": u["email"], "username": u["username"], "first_name": u["first_name"],
            "last_name": u["last_name"], "language": u.get("language", "en"),
            "root_admin": u.get("root_admin", False), "password": password})

    async def get_server(self, sid: int) -> dict:
        return (await self._req("GET", f"/servers/{sid}"))["attributes"]

    async def list_servers(self) -> List[dict]:
        out, page = [], 1
        while True:
            d = await self._req("GET", "/servers", params={"per_page": 100, "page": page})
            out += [x["attributes"] for x in d.get("data", [])]
            if page >= d.get("meta", {}).get("pagination", {}).get("total_pages", 1):
                return out
            page += 1

    async def power(self, identifier: str, signal: str) -> None:
        """signal: start | stop | restart | kill  (Client API)"""
        await self._req("POST", f"/servers/{identifier}/power", json={"signal": signal}, client=True)

    async def state(self, identifier: str) -> dict:
        return (await self._req("GET", f"/servers/{identifier}/resources", client=True))["attributes"]

    # ---------- v3: application API ----------
    async def _all(self, path: str) -> List[dict]:
        out, page = [], 1
        while True:
            d = await self._req("GET", path, params={"per_page": 100, "page": page})
            out += [x["attributes"] for x in d.get("data", [])]
            if page >= d.get("meta", {}).get("pagination", {}).get("total_pages", 1):
                return out
            page += 1

    async def total(self, path: str) -> int:
        d = await self._req("GET", path, params={"per_page": 1})
        return d.get("meta", {}).get("pagination", {}).get("total", 0)

    async def list_nodes(self): return await self._all("/nodes")
    async def list_locations(self): return await self._all("/locations")
    async def list_nests(self): return await self._all("/nests")
    async def list_eggs(self, nest: int): return await self._all(f"/nests/{nest}/eggs")

    async def list_users(self, page: int = 1, per: int = 10):
        d = await self._req("GET", "/users", params={"page": page, "per_page": per})
        return [x["attributes"] for x in d.get("data", [])], d.get("meta", {}).get("pagination", {})

    async def update_user(self, uid: int, **changes) -> None:
        u = await self.get_user(uid)
        payload = {"email": u["email"], "username": u["username"], "first_name": u["first_name"],
                   "last_name": u["last_name"], "language": u.get("language", "en"),
                   "root_admin": u.get("root_admin", False)}
        payload.update(changes)
        await self._req("PATCH", f"/users/{uid}", json=payload)

    async def update_build(self, sid: int, *, memory=None, disk=None, cpu=None,
                           databases=None, backups=None, allocations=None) -> None:
        s = await self.get_server(sid)
        lim, fl = s["limits"], s["feature_limits"]
        pick = lambda new, old: old if new is None else new
        await self._req("PATCH", f"/servers/{sid}/build", json={
            "allocation": s["allocation"], "memory": pick(memory, lim["memory"]), "swap": lim.get("swap", 0),
            "disk": pick(disk, lim["disk"]), "io": lim.get("io", 500), "cpu": pick(cpu, lim["cpu"]),
            "threads": lim.get("threads"), "oom_disabled": lim.get("oom_disabled", True),
            "feature_limits": {"databases": pick(databases, fl.get("databases", 0)),
                               "backups": pick(backups, fl.get("backups", 0)),
                               "allocations": pick(allocations, fl.get("allocations", 1))}})

    async def update_details(self, sid: int, *, user_id=None, name=None) -> None:
        s = await self.get_server(sid)
        await self._req("PATCH", f"/servers/{sid}/details", json={
            "name": name or s["name"], "user": user_id or s["user"],
            "description": s.get("description") or "", "external_id": s.get("external_id")})

    async def reinstall_app(self, sid: int) -> None:
        await self._req("POST", f"/servers/{sid}/reinstall")

    # ---------- v3: client API ----------
    async def send_command(self, ident: str, command: str) -> None:
        await self._req("POST", f"/servers/{ident}/command", json={"command": command}, client=True)

    async def rename(self, ident: str, name: str) -> None:
        await self._req("POST", f"/servers/{ident}/settings/rename", json={"name": name}, client=True)

    async def reinstall_client(self, ident: str) -> None:
        await self._req("POST", f"/servers/{ident}/settings/reinstall", client=True)

    async def create_backup(self, ident: str, name: str = "") -> dict:
        d = await self._req("POST", f"/servers/{ident}/backups", json={"name": name} if name else {}, client=True)
        return d.get("attributes", {})

    async def list_backups(self, ident: str) -> List[dict]:
        d = await self._req("GET", f"/servers/{ident}/backups", client=True)
        return [x["attributes"] for x in d.get("data", [])]

    async def delete_backup(self, ident: str, uuid: str) -> None:
        await self._req("DELETE", f"/servers/{ident}/backups/{uuid}", client=True)

    async def list_files(self, ident: str, directory: str = "/") -> List[dict]:
        d = await self._req("GET", f"/servers/{ident}/files/list", params={"directory": directory}, client=True)
        return [x["attributes"] for x in d.get("data", [])]

    async def startup_vars(self, ident: str):
        d = await self._req("GET", f"/servers/{ident}/startup", client=True)
        return d.get("meta", {}), [x["attributes"] for x in d.get("data", [])]

    async def set_variable(self, ident: str, key: str, value: str) -> None:
        await self._req("PUT", f"/servers/{ident}/startup/variable", json={"key": key, "value": value}, client=True)

    async def list_databases(self, ident: str) -> List[dict]:
        d = await self._req("GET", f"/servers/{ident}/databases", client=True)
        return [x["attributes"] for x in d.get("data", [])]

    async def list_schedules(self, ident: str) -> List[dict]:
        d = await self._req("GET", f"/servers/{ident}/schedules", client=True)
        return [x["attributes"] for x in d.get("data", [])]

    async def network(self, ident: str) -> List[dict]:
        d = await self._req("GET", f"/servers/{ident}/network/allocations", client=True)
        return [x["attributes"] for x in d.get("data", [])]
