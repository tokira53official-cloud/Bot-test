"""Small helpers shared by the server-control / admin cogs."""
from datetime import datetime

from .embeds import e_err, send_embed
from .ptero import PteroError


async def resolve_server(ctx, server_id: int):
    """Returns the DB row if the caller owns it (or is an admin/owner); otherwise sends an error and returns None."""
    bot = ctx.bot
    row = await bot.db.get_server(server_id)
    is_admin = ctx.author.id in bot.cfg.owner_ids or ctx.author.id in bot.admin_ids
    if not row or (row["discord_id"] != ctx.author.id and not is_admin):
        await send_embed(ctx, e_err("Not found", "That server isn't yours (or isn't tracked by the bot)."), delete_after=10)
        return None
    return row


async def guard(ctx, coro):
    """Awaits a panel call; on failure shows a red embed. Returns (ok, result)."""
    try:
        return True, await coro
    except PteroError as e:
        await send_embed(ctx, e_err("Panel error", e.message[:300]), delete_after=12)
        return False, None


def fmt_bytes(n) -> str:
    n = float(n or 0)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.0f} B" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024


def fmt_duration(ms) -> str:
    s = int((ms or 0) / 1000)
    d, s = divmod(s, 86400)
    h, s = divmod(s, 3600)
    m, s = divmod(s, 60)
    return f"{d}d {h}h {m}m {s}s"


def ts(iso) -> int:
    try:
        return int(datetime.fromisoformat(str(iso).replace("Z", "+00:00")).timestamp())
    except Exception:
        return 0
