"""Shared logic: roles, server provisioning and the !free/!premium/!vip claim flow."""
import logging
from typing import Optional

import discord

from .embeds import e_done, e_err, e_prog, edit_embed, send_embed
from .ptero import PteroError

log = logging.getLogger("service")

KIND_ALIASES = {"js": "js", "node": "js", "nodejs": "js", "py": "py", "python": "py",
                "mc": "mc", "minecraft": "mc"}


class ProvisionError(Exception):
    pass


def server_url(cfg, identifier: str) -> str:
    return f"{cfg.ptero_url}/server/{identifier}"


async def _member(bot, user_id: int) -> Optional[discord.Member]:
    guild = bot.get_guild(bot.cfg.guild_id)
    if not guild:
        return None
    m = guild.get_member(user_id)
    if m is None:
        try:
            m = await guild.fetch_member(user_id)
        except discord.HTTPException:
            return None
    return m


async def give_role(bot, user_id: int, role_id: int, reason: str = "") -> bool:
    if not role_id:
        return False
    m = await _member(bot, user_id)
    role = m.guild.get_role(role_id) if m else None
    if not m or not role:
        return False
    try:
        await m.add_roles(role, reason=reason or "PteroManager")
        return True
    except discord.HTTPException:
        log.warning("could not add role %s to %s", role_id, user_id)
        return False


async def take_role(bot, user_id: int, role_id: int, reason: str = "") -> bool:
    if not role_id:
        return False
    m = await _member(bot, user_id)
    role = m.guild.get_role(role_id) if m else None
    if not m or not role:
        return False
    try:
        await m.remove_roles(role, reason=reason or "PteroManager")
        return True
    except discord.HTTPException:
        return False


async def provision(bot, discord_id: int, tier_key: str, kind_key: str,
                    name: Optional[str] = None, bypass: bool = False) -> dict:
    cfg = bot.cfg
    tier, kind = cfg.tiers[tier_key], cfg.kinds[kind_key]
    if not kind.egg_id or not kind.nest_id:
        raise ProvisionError(f"The {kind.label} egg is not configured in `.env`.")
    acct = await bot.db.get_account(discord_id)
    if not acct:
        raise ProvisionError("No linked panel account. Use `" + cfg.prefix + "link` first.")

    name = (name or f"{tier.label} {kind.label} {acct['username']}")[:60]
    status, val = await bot.db.reserve_server(
        discord_id, tier_key, kind_key, name, tier.max_per_user, tier.global_limit, bypass)
    if status == "global_limit":
        raise ProvisionError(f"**{tier.label}** servers are closed — the limit of {tier.global_limit} has been reached.")
    if status == "user_limit":
        raise ProvisionError(f"You already have {val}/{tier.max_per_user} **{tier.label}** server(s).")
    rid = val

    try:
        s = await bot.ptero.create_server(
            name=name, user_id=acct["ptero_user_id"], nest=kind.nest_id, egg=kind.egg_id,
            ram=tier.ram, disk=tier.disk, cpu=tier.cpu, databases=tier.databases,
            backups=tier.backups, allocations=tier.allocations, locations=cfg.locations)
    except PteroError as e:
        await bot.db.fail_server(rid)
        raise ProvisionError(f"Panel error: {e.message[:300]}")
    except Exception:
        log.exception("create_server crashed")
        await bot.db.fail_server(rid)
        raise ProvisionError("Unexpected error while creating the server.")

    try:
        await bot.db.finalize_server(rid, s["id"], s["identifier"])
    except Exception:
        log.exception("finalize failed — recorded in data_recovery.jsonl")
    try:
        await bot.db.bump_stat(discord_id, servers=1)
    except Exception:
        log.exception("stat bump failed")
    return {"id": s["id"], "identifier": s["identifier"], "name": name, "tier": tier, "kind": kind,
            "url": server_url(cfg, s["identifier"])}


async def claim(ctx, tier_key: str, kind_arg: str) -> None:
    """Used by !free / !premium / !vip."""
    bot, cfg = ctx.bot, ctx.bot.cfg
    tier = cfg.tiers[tier_key]
    kind_key = KIND_ALIASES.get(kind_arg.lower())
    if not tier.enabled:
        return await send_embed(ctx, e_err("Disabled", f"`{cfg.prefix}{tier_key}` is currently disabled."), delete_after=10)
    if not kind_key:
        return await send_embed(ctx, e_err("Unknown type", "Choose one of: `js`, `py`, `mc`."), delete_after=10)
    if tier_key != "free" and ctx.author.id not in cfg.owner_ids:
        guild = ctx.guild or bot.get_guild(cfg.guild_id)
        member = guild.get_member(ctx.author.id) if guild else None
        if not tier.role_id or not member or tier.role_id not in [r.id for r in member.roles]:
            return await send_embed(ctx, e_err("Not allowed", f"You need the **{tier.label}** role to use this."), delete_after=10)

    msg = await send_embed(ctx, e_prog("Creating your server…", f"Deploying a **{cfg.kinds[kind_key].label}** server."))
    try:
        r = await provision(bot, ctx.author.id, tier_key, kind_key, bypass=ctx.author.id in cfg.owner_ids)
    except ProvisionError as e:
        return await edit_embed(msg, e_err("Could not create server", str(e)))
    t = r["tier"]
    emb = e_done("Server created", f"**{r['name']}**\n[Open in panel]({r['url']})")
    emb.add_field(name="Specs", value=f"RAM `{t.ram} MB`\nDisk `{t.disk} MB`\nCPU `{t.cpu}%`", inline=True)
    emb.add_field(name="Info", value=f"ID `{r['id']}`\nType `{r['kind'].label}`\nTier `{t.label}`", inline=True)
    await edit_embed(msg, emb)


async def notify_suspension(bot, attrs: dict, suspended: bool):
    """DM the server's owner. Returns True (sent), False (DMs closed) or None (owner not linked)."""
    acct = await bot.db.account_by_ptero_user(attrs.get("user"))
    if not acct:
        return None
    name = attrs.get("name", "Your server")
    if suspended:
        e = e_err("Your server was suspended",
                  f"**{name}** (ID `{attrs['id']}`) has been suspended.\nIf you think this is a mistake, contact an admin.")
    else:
        e = e_done("Your server was unsuspended", f"**{name}** (ID `{attrs['id']}`) is available again.")
    try:
        user = bot.get_user(acct["discord_id"]) or await bot.fetch_user(acct["discord_id"])
        await send_embed(user, e)
        return True
    except discord.HTTPException:
        return False


async def dm(bot, user_id: int, embed) -> bool:
    try:
        user = bot.get_user(user_id) or await bot.fetch_user(user_id)
        await send_embed(user, embed)
        return True
    except discord.HTTPException:
        return False
