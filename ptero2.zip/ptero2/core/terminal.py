"""Red-to-white gradient ASCII banner for the terminal."""
try:
    import pyfiglet
except ImportError:
    pyfiglet = None


def print_banner(text: str) -> None:
    art = pyfiglet.figlet_format(text, font="slant") if pyfiglet else text
    lines = [l for l in art.splitlines() if l.strip()]
    n = max(len(lines) - 1, 1)
    for i, line in enumerate(lines):
        g = b = int(255 * i / n)
        print(f"\033[38;2;255;{g};{b}m{line}\033[0m")
    print()
