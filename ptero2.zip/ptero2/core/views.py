import discord
from discord import ui


class ConfirmView(ui.View):
    def __init__(self, uid: int, timeout: float = 30):
        super().__init__(timeout=timeout)
        self.uid = uid
        self.value = None

    @ui.button(label="Confirm", style=discord.ButtonStyle.danger, row=0)
    async def yes(self, inter: discord.Interaction, button: ui.Button):
        if inter.user.id != self.uid:
            return
        self.value = True
        await inter.response.defer()
        self.stop()

    @ui.button(label="Cancel", style=discord.ButtonStyle.secondary, row=0)
    async def no(self, inter: discord.Interaction, button: ui.Button):
        if inter.user.id != self.uid:
            return
        self.value = False
        await inter.response.defer()
        self.stop()
