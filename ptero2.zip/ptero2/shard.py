"""Entry point. Runs the bot with automatic sharding.   python shard.py"""
import logging
import sys

from core.config import cfg
from core.terminal import print_banner


def main() -> None:
    print_banner(cfg.bot_name)
    problems = cfg.validate()
    if problems:
        print("Fix your .env (copy .env.example to .env):")
        for p in problems:
            print("  •", p)
        sys.exit(1)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    from core.bot import PteroBot
    PteroBot(cfg).run(cfg.token, log_handler=None)


if __name__ == "__main__":
    main()
